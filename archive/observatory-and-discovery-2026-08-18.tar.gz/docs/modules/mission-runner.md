---
module: mission-runner
source: src/mission-runner.js
source_hash: ed0b22b90536b83e7444e483748536a80bbdd484ab6374dcabae04931003474c
updated: 2026-08-03
---

# Module: mission-runner

## Purpose

Runs one discovery mission at a time and **owns the traceroute while it does**.

Peter, 2026-08-02: *"the traceroute should be used by us, when a discovery is in
progress"* and *"if a traceroute was last done 4 days ago, then our entire page is
dead and old data. traceroute is our primary tool, we dont just use the
historical stats, when we are targeting a discovery / node we need traceroute!"*

## Why it exists

Every panel on the Observatory derives from `traceroute_history`. That table's
last real activity was **27 July** — `traceroute.enabled` was set false and the
attempt rate fell from ~1,000/day to 1. The board was reporting a five-day-old
mesh as though it were current.

And the prober it replaces was **reactive**: `passive-tracer` traces whatever it
has just heard. That is why 5,046 attempts went to 335 targets that have never
answered — we keep hearing them, so it keeps asking — while 213 positioned nodes
were never tried once. A reactive prober can only ever confirm the shape of what
already arrives. It cannot *pursue*.

## A traceroute is a survey, not a ping

This is the reason discovery gets the instrument. Measured 2026-08-02:

| | |
|---|---|
| relays we depend on | 79 |
| …never heard directly — **the route is the only evidence they exist** | 69 |
| …appearing **only on return legs** | 23 |
| …with no position | 21 |
| …absent from the `nodes` table entirely | 2 |

Plus per-hop SNR in **both** directions, on segments we can never measure
ourselves. One reply can name a relay, place it, draw two links and move the
record. That is what the activity table reports — not hit/miss.

## One owner at a time

`mission-runner` takes a lock for the duration of a mission. While it is held:

- `passive-tracer` yields — but only while a packet is **actually in the air**
  (`dispatching`), not for the whole time a mission is in hand (`busy`). See
  below; getting this wrong took the passive tracer to near zero.
- A second mission does not start. Serial by design: two traceroutes in flight
  make the SNR attribution ambiguous and double the airtime for no extra
  information.

A **manual** traceroute is never blocked. `traceroute.dispatch({manual:true})`
bypasses the master switch already, and a person asking is always more important
than the schedule.

### `busy` vs `dispatching` — two different questions

| getter | true when | who asks |
|---|---|---|
| `busy` | a mission is **in hand** — aiming, holding, dispatching, waiting | the panel; the guard against a second mission |
| `dispatching` | a discovery **packet is in the air**, until its reply or timeout | `passive-tracer` |

The yield was first written against `busy`. That covers the entire cycle, and the
runner holds one target for six attempts across roughly **18 minutes**, so passive
almost never got a window: 17.0 traces/hour became 0.1 (measured 2026-08-02).
Passive was the half that was answering — 3.8% over 5,557 traces, against 0.0%
for 132 aimed missions in the same period.

"A discovery is in progress" means the seconds a reply is expected, not the twenty
minutes a target sits queued. `dispatching` says that; `busy` does not.

**Honest limit:** narrowing this gate was *not* what had actually stopped the
passive tracer. `passive-tracer.js` separately tested `dashMode.value !== 0` and so
was switched off entirely in DISC — `busy` never got the chance to block anything.
Both were real defects; only the second explains the measured collapse. See
`docs/modules/passive-tracer.md`.

## It aims before it fires

The first version did not, and it showed: a 234 km attempt went out on the omni
with `rotator_az` null on the stored row. A directional antenna pointed at
nothing is a *worse* antenna than an omni, not a better one.

`reach.mission` now carries the target's `bearing` (already computed by
`reach.target`, simply not forwarded). Before dispatch the runner calls
`rotator.point(bearing)` and **waits for the device's own `done` event** — no
polling, no tolerance loop, no reimplementation of a point function the firmware
already has. See `docs/modules/rotator.md`.

`busy/held` puts the mission **back on the queue**. The YAGI is shared with the
garage alarm, which points it and holds it; firing an unaimed shot at a 234 km
target would spend the airtime and prove nothing.

A mission with no bearing does not aim and says so — it still goes out, because a
route to an unplaced node is exactly how we learn where it is.

Verified live: `WIST 234.2 km, bearing 11 → aimed 11°`, stored as
`tx F4:12:FA:39:F7:B6, rotator_az 10`. The YAGI, on the beam, at the frontier.

### The v4 does not always reach its target, and says so

```
started {"evt":"started","cmd":"seek2az","target":30}
done    {"evt":"done","cmd":"seek2az","az":7,"ok":false}
```

It accepted the command, moved, stopped **23° short** and reported the failure
honestly. (The v5 on `.195` is closed-loop on an encoder to 0.5° and would not
do this — it is currently unreachable.)

Treating `ok:false` as fatal meant **every mission deferred forever and the queue
never drained** — a full queue, zero attempts, and nothing anywhere saying why.

So a near miss is **accepted and named**. A 23° miss on a 35° beam still puts the
target inside the main lobe, and transmitting slightly off-boresight is
enormously better than not transmitting at all:

| miss | outcome |
|---|---|
| ≤ half beam | `aimed 31°` |
| ≤ full beam | `aimed 31° — 12° off, inside the 35° beam` |
| > full beam | deferred; the shot would prove nothing about the target |

One re-issue before judging — the v4 often lands closer on a second, shorter
move (measured: 7° on the first attempt, 30° on the second). A third would be
stubbornness.

**The azimuth recorded on the attempt is the one achieved, never the one asked
for.** Anything later reading `rotator_az` gets where the beam actually was.

### The feed survives a restart

`_recent` is in-memory and pm2 watches `src/`, so every edit emptied the table
and the panel announced *"no attempt has completed yet this session"* while the
runner was mid-stride. That reads as **nothing is happening** — precisely the
impression this panel exists to prevent, and precisely the complaint that led
here.

The attempts were never lost; they are rows in `traceroute_history`.
`observatory-ws` replays the 25 most recent **aimed** dispatches
(`db.recentAimedTraceroutes` — `rotator_az IS NOT NULL` is what distinguishes a
mission from a passive trace of whatever happened to arrive) so the feed opens
populated.

Seeded rows carry `seeded: true` and do **not** claim what they revealed. The
discovery counters are session state, and re-deriving them from storage would be
inventing history. They say what happened and when, and nothing more.

### A deferral leaves a trace

`[mission] deferred ?5C3: move failed: unknown` — without it the runner sat with
a full queue and zero attempts and there was nothing to explain it, because a
deferred mission never reaches `recent`. An invisible skip is indistinguishable
from a dead loop.

## Only in DISC mode

Mode owns every per-mode behaviour including which radio transmits (Peter's
standing rule), so the runner reads `dashMode` and idles in every other mode. See
`docs/modules/dash-mode.md`.

## Scheduling — rescheduled in a `finally`, and nowhere else

The first version called `_schedule()` on each of the five return paths inside
`_tick()`, and the timer ran `this._tick().catch(() => {})`. Any throw anywhere
in a tick was therefore swallowed **and** skipped every one of those calls: the
runner died permanently, silently, with a full queue. It managed exactly one
mission before stopping.

Peter, 2026-08-02: *"you see WIST is hard coded, it has made one attempt and
failed, but we have a whole list of targets dont we?"* — not hardcoded, but he
was right that it was stuck. Measured at the time: **queue 18, attempts 1, seven
minutes idle** with the rotator free.

A loop whose continuation depends on remembering to reschedule on every branch is
a loop that will stop. Now there is one `_schedule()` call, in a `finally`, and
failures are logged rather than discarded.

### It sticks with a target until the budget is spent

`attempts_per_target` was shipped in `67b45a9` and did **nothing**. Measured
2026-08-02 14:44: the previous 90 minutes were **22 targets, 22 attempts** —
exactly one each, the behaviour the setting was introduced to replace.

The cause was a bare `_queue.shift()`. The shortlist is only refreshed on the
15-minute recompute, and by then the target just attempted is inside its
30-minute cooldown and excluded, so a fresh set of ~15 different candidates
replaced it. The budget could never be spent.

The runner now **holds** a mission and its remaining shots, re-attempting the
same target each tick until either it answers or the budget runs out. The
cooldown still governs re-selection much later; it simply no longer governs the
burst, which is what it was accidentally doing.

**A reply ends the run early.** The budget exists to find out whether a path is
there; once it has answered there is nothing more to learn from hitting it
again, and the airtime is better spent on the next target.

**A deferral does not spend a shot.** If the beam was unavailable the target
stays in hand — nothing was tested, so nothing is charged.

Verified: node `1519572419` (191.4 km, +3.6 km step) received **six consecutive
attempts** between 14:51 and 15:06, against one-each before.

### Cadence is measured from the START of a tick

A mission can take three minutes of its own — up to 90 s aiming the beam, 90 s
waiting for a reply that never comes. Rescheduling from the *end* would silently
halve the configured rate. The next tick is scheduled at
`interval − elapsed`, with a 5 s floor so a long mission cannot immediately
trigger the next one.

## Settings come from the `discovery` key

`interval_sec` and `enabled` are read from `discovery`
(`docs/DISCOVERY_STRATEGY.md`) on **every tick**, so a change from the dashboard
takes effect on the next mission with no restart.

`hold_sec`, `aim_timeout_sec`, `mission_timeout_sec` and `aim_patience_sec` are
read from `discovery` too. `recent` stays in this module's own `DEFAULTS` and is
deliberately not exposed: how many rows the feed keeps changes no measurement.

`aim_patience_sec` (default **5 s**, bounded `[0, 60]`) is how long `point()` may
queue for a beam another user holds. It is a **ceiling**, not a promise — the
rotator reports the milliseconds left, and a hold longer than this is the garage
alarm using the beam, where queueing would starve the alarm rather than help us.
`0` restores the old behaviour of giving up the whole tick on any hold.

## Aiming is one call, because the negotiation is the rotator's

`_aim()` makes a single `rotator.point(bearing, { timeoutMs, hold, patienceMs })`
call. It does not sleep, retry a held beam, or issue its own `hold()` — all three
belong to `point()`, which is the SSOT for talking to the rotator
(`docs/modules/rotator.md`). Peter, 2026-08-03: *"one SSOT with rotator handshake
and intelligent decisions and modes."*

This module supplies the **policy** and reads the **answer**:

| from config | passed as | means |
|---|---|---|
| `hold_sec` | `hold` | hold the beam this long once it lands |
| `aim_patience_sec` | `patienceMs` | queue this long for a beam someone else holds |
| `aim_timeout_sec` | `timeoutMs` | backstop for a device that never answers |

When the beam is still held after `point()` has done its waiting, the mission
yields for the tick and the note carries `retryInMs` — *"beam held by another
user — free in ~9960 ms"*. Previously the note said only "beam held by another
user", which is indistinguishable from a dead rotator in the log, and the tick was
given up over holds as short as **423 ms**.

## The beam is held while the shot goes out

`hold_sec × 1000` is handed to `point()`, which issues the hold as part of the
same call — not as a second call after the aim.
Default 15 s — sized to the real reply window (a measured manual round trip took
**2.9 s**) rather than to the 90 s timeout, which would monopolise an antenna the
garage alarm also needs. `0` disables it.

**An off-beam shot is not charged to the target.** The azimuth is re-read at
dispatch, not trusted from the `done` event, and if the beam has moved outside
the beamwidth the mission is deferred without spending one of its attempts — it
tested nothing about the target, so charging it would be a lie. (B58.)

### Why the hold moved inside `point()`

Aim-then-hold was two calls with a gap between them, and that gap is precisely
when another user can take the beam. It was also code every future caller would
have had to copy correctly.

### The setting existed and did nothing, briefly

`cfg()` whitelisted only `interval_sec` and `enabled` from the `discovery` key,
so `hold_sec` read as `undefined` and no hold was ever sent — while the UI showed
the control and the config stored the value. Caught by watching the rotator's own
frames rather than trusting that the code path ran. The whitelist is now explicit
and complete for what this module reads.

Verified live: `ROTATOR held=true holdMs=14984 az=241` during a real mission.

### The off-beam guard reads the landing, not a status re-read

`aim.az` — the azimuth the rotator reported in its `done` event — is preferred
over `rotator.status.az`. The status frame is asynchronous and can lag a move;
the `done` event is the device's own statement of where it stopped.

Reading status instead cost eleven minutes of blocked missions: the guard saw a
mid-travel 141° against a wanted 219° that the rotator had already reached, and
deferred every attempt. A guard against firing off-beam is worthless if its own
input is stale.

### The timings are the operator's, not the module's

`timeout_sec` and `aim_timeout_sec` were module constants at 90 s. Both are now
read from the `discovery` key, because both can change what gets measured —
`timeout_sec` in particular decides what counts as a miss and sets the true
cadence. `recent` stays private: how many rows the feed keeps changes no
measurement.

## Airtime governance — a budget and a brake

`max_attempts_per_day` (400) is a hard rolling-24h cap; `channel_util_pause`
(50%) skips a tick while our own radios report the channel busier than that.
Both are checked **before** anything is selected, so a braked tick costs nothing.

**The rationale is courtesy and control, not a measured speed-up.** High-volume
days do answer worse (`MESH_REACH_SPEC` §3b) but the congestion explanation for
it is *disproved* — answer rate is flat against both channel utilisation and our
own transmit duty. These knobs bound what we put on a shared band and make the
rate an experiment we can run; they are not known to improve anything.

Utilisation is read from **our radios' telemetry** via `ourChannelUtil()`, using
`ownDeviceNums()` for which nums are ours. The first attempt read
`rotator.status.channel_util`, which does not exist — the rotator reports no such
field. The busiest of our radios wins: if either sees a loaded channel, adding to
it is what the brake is for.

**A brake is always surfaced** (`brake` in the state, `PAUSED — …` on the panel),
never a silent skip. An invisible pause reads exactly like a dead loop, and this
panel has already been caught by that once.

Verified live: threshold set to 5% against 30% measured →
`channel 30% busy, over 5%`. Clamps hold — 99999 → 5000, 0 → 1.

## Rate

One attempt every **180 s** (config `mission_runner.interval_sec`), ≈ 480/day
against the old ~1,000/day in bursts. Peter's *"not so much as to become a
nuisance"* (§1) with a number attached, and steady rather than bursty so the
mesh sees a constant trickle instead of a flood and then silence.

Per-target cooldown is the selector's, not this module's
(`docs/modules/inferences.md`).

## Boundary

**It does not import `observatory.js`.** That would be a fourth importer and the
boundary test permits three. `observatory-ws.js` — already an allowed importer —
feeds the shortlist in via `setQueue()` and broadcasts the activity events out.
The runner is a dumb executor: it is handed a list and it works it.

## Interface

```js
setQueue(missions)   // the shortlist, highest priority first
state()              // { enabled, running, current, recent[], discovered }
get busy             // → bool — a mission is in hand (aim/hold/dispatch/wait)
get dispatching      // → bool — a packet is in the air; what passive-tracer yields to
events: 'activity'   // emitted on every state change
```

## The probe narrates itself

Task `hooks-discovery-path`. Peter, 2026-08-03: *"what I expect to see is a log for each
probe, showing the steps that we are cycling through, instead of hiding what is being done
in the code."*

Five hooks, declared in `mission-runner.js` in the order they run (registration order is
execution order — see `docs/modules/hooks.md`):

| hook | scope | says |
|---|---|---|
| `discovery-idle` | per-mode `disc` | why the loop is not probing |
| `select-target` | per-node | which candidate, and the ranker's reason |
| `aim-antenna` | per-node | the bearing wanted and what the beam reports |
| `dispatch-trace` | per-node | the send, the radio, the timeout |
| `record-outcome` | per-node | the reply, or that none came |

A real trace, 2026-08-03:

```
select-target   chose HEGM at 97.5 km — 6 attempts, no reply yet — 16 km past the nearest node…
aim-antenna     aimed at 108°, beam reports 107°
dispatch-trace  traceroute → HEGM via !fa39f7b4, waiting up to 90s
record-outcome  HEGM: no reply after 90s                             [notice]
aim-antenna     aimed at 108°, beam reports 108°        ← attempt 2 of 6
dispatch-trace  traceroute → HEGM …
```

**One `probe_id` spans a whole target run, not one attempt.** The six shots at a candidate
are one investigation and read as one trace: `select-target` fires once, then
aim/dispatch/outcome repeat. That is ~19 rows per target run, ~3,800/day at current
cadence — inside the retention design.

### The five-reason silent return, now named

The loop stopped on any of five conditions with a bare `return`:

```js
if (mode !== 'disc' || c.enabled === false || !tracerouteEnabled()
    || this.busy || (!this._queue.length && !this._holding)) return;
```

Identical in shape to the gate that hid passive tracing for 9.5 hours. Each now has a
sentence, and **recovery is reported too** — a fault that never announces its end leaves
the reader unsure whether it is still live:

```
10:46:53  not probing — no candidates — the shortlist is empty
10:58:53  probing resumed (was: no candidates — the shortlist is empty)
```

`_sayIdle()` latches on the reason so only CHANGES emit. The tick runs every 180 s and a
per-tick line would bury the one that matters — the same "notification you stop reading"
failure as a bar of permanently-green badges.

`busy` is deliberately NOT a reason: a probe in hand is normal, not an explanation.

### The ranker's reason is no longer thrown away

`reach.mission` computes a `reason` string per candidate and, until now, discarded it after
sorting. It is the answer to "why this one" and now rides `select-target`.

### Known cosmetic inconsistency

`dispatch-trace` reports the radio as a node id (`!fa39f7b4`) because that is what
`transmitterForMode()` returns, while most of the codebase speaks MAC. Not corrected here —
it is a display nit in one string, and changing the transmitter vocabulary is a separate
concern.

## Invariants

- Never more than one mission in flight.
- A mission never dispatches while `traceroute.enabled` is false.
- Discovery counts describe what a route *revealed*, and are computed from
  stored state before the route is folded in — never after, or everything looks
  already-known.
- A failure is recorded and shown. §4: a miss is data.

## Out of scope

- Selection — that is `reach.mission` in the catalogue.
- The broadcast callout. Still unbuilt, still the contested instrument (§9).
- Anything the rotator does. A mission uses the mode's transmitter and does not
  aim; the antenna is shared with the garage alarm.

## B75 — the daily airtime budget must survive a restart

`max_attempts_per_day` was enforced against `this._sent`, an **in-memory array**
initialised empty in the constructor. Every process restart returned the budget
to zero, so the cap bounded *attempts since the last deploy*, not attempts per
day.

Measured 2026-08-03 23:31: **1229 attempts in the preceding 24 h against a cap of
400** — three times over, because node-dash was restarted five times that evening
while shipping. The brake was never broken; it was repeatedly released, and
nothing reported the overrun because from each fresh process's view it had not
happened.

Peter, when the cap was then raised to 2000: *"but that does not mean that you
gate bug does not need fixing"* — correct. A larger cap on a counter that resets
is still a cap that means nothing.

### The count comes from the store

```sql
SELECT COUNT(*) FROM traceroute_history
 WHERE ts > strftime('%s','now') - 86400 AND tx_device IS NOT NULL
```

Two details that are not optional:

- **`tx_device IS NOT NULL`** excludes overheard/passive traceroutes. Those cost
  us no airtime, and counting another station's traffic against our own budget
  would brake us for someone else's transmissions. (Last 24 h: 1229 ours, 1
  overheard — small tonight, wrong in principle always.)
- **plus anything in flight.** A row is written at RESULT time — `setTraceroute`
  on success, `_recordFailure` on timeout or send failure — so a dispatched
  attempt is invisible to the query for up to `timeout_sec`. Without this the
  budget would undercount by the mission currently running.

Same failure class as B74: state that silently resets to a **permissive** value
rather than failing closed. A budget that forgets is worse than no budget,
because it reports compliance while exceeding.

### Verified

Process restarted at 23:38:35 on code modified 23:38:17. A fresh process now
reports `sentToday() = 1228` (cap 2000, 772 remaining tonight). Under the
in-memory array a fresh process necessarily reported **0** — that is the whole
defect, and it is deterministic rather than something that needed re-running.

`sent_today` is published on the runner's own emission, not on
`missions.summary`, so it is not readable from the Observatory board payload.
