// OBSERVATORY — WebSocket wiring. NOT CORE.
//
// Same shape and the same reason as alarm-ws.js: src/ws-relay.js serves the WS
// for every page and must not name a plugin. This file knows the observatory;
// core does not know this file. Delete it and its one import in index.js and
// core is unchanged.
//
// It is the THIRD file permitted to import observatory.js, and that is a
// deliberate decision rather than a boundary quietly slipping. The rule the
// test encodes is "CORE must not reach into the engine". This is a plugin — the
// engine's own WS wiring — exactly as alarm-ws.js is the alarm's. The allowlist
// names it explicitly so a fourth entry is again a visible choice.
//
// See docs/WS_PLUGIN_HOOKS_SPEC.md and docs/PLUGIN_BOUNDARY_SPEC.md.
import { events, recentObservations, facts, runInference } from './observatory.js';
import { registerWsWiring, registerConnectReplay, registerSettingsListener } from './ws-relay.js';
import { onEvent, listHooks } from './hooks.js';
import { resolveNodeLabel } from './node-label.js';
import { mqttDiscarded } from './observations.js';
import { missionRunner } from './mission-runner.js';
import { hitRateVerdict } from './signal-verdict.js';

// first_recompute_ms — wait for the store and gw connection to be up before
//   the first inference sweep. Basis: boot to first packet, observed.
// runner_start_ms — the discovery runner starts AFTER that sweep, so its
//   shortlist is built from fresh facts rather than an empty fact table.
//
// Declared and overridable — Peter, 2026-08-04: "all timings need to be vars.
// some if not all will be selected to be configurables / knobs."
const TIMING_DEFAULTS = { first_recompute_ms: 10_000, runner_start_ms: 20_000 };
const timing = () => ({ ...TIMING_DEFAULTS, ...(getConfig('observatory_timing', {}) || {}) });

import db, { getConfig, getCachedGeocode, recentAimedTraceroutes, lastHeardMap, positionMap, listObsTargets,
         attemptsByDay, answerRateBySilence, answerRateByDistance,
         rateByBandByDay, windowBestKm, boardVerdicts, recentEventLog, interventions } from './db.js';
import { discoveryConfig } from './config-api.js';

// Read once: the map marks where we are, and the reach model already computes
// every distance from it. A page load must not re-read config.
const HOME = { lat: getConfig('home.lat'), lon: getConfig('home.lon') };

// How much history a freshly-connected page starts with. On a quiet channel a
// page that waits for the next packet looks broken for minutes, so it opens with
// the recent past already on screen and grows from there.
const REPLAY_LIMIT = 200;

/** One stored row as a WS message.
 *
 *  `data` is re-parsed rather than passed through as a string: the browser must
 *  not be handed JSON-inside-JSON to unpick. Parse failures yield null instead
 *  of throwing — a single malformed payload must not stop the feed.
 *
 *  BROWSER_CONTRACT: this is raw observation data, not display values. Anything
 *  the page needs FORMATTED (relative ages, labels) is a server-computed field
 *  and must be added here, never derived in the browser. */
function toMessage(row) {
  let data = null;
  try { data = row.data ? JSON.parse(row.data) : null; } catch { data = null; }
  return { id: row.id, ts: row.ts, kind: row.kind, entity: row.entity, source: row.source, data };
}

// Live pushes. Core hands us `broadcast`; we know the observatory, core does not
// know us.
let _broadcast = null;
registerWsWiring(({ broadcast }) => {
  _broadcast = broadcast;
  // Live, one row at a time, as it is emitted — not on the 15-minute recompute.
  // This is what makes the page a feed rather than a report.
  onEvent(row => {
    try { broadcast({ type: 'event', event: row }); }
    catch (e) { console.error(`[observatory-ws] event push failed: ${e.message}`); }
  });
  events.on('observation', (row) => {
    // WRAPPED. This runs inside observe(), which runs inside handlePacket, which
    // is the hot path for every packet. A throw here — a dead socket, a JSON
    // problem — must not reach packet ingestion.
    try { broadcast({ type: 'observation', observation: toMessage(row) }); }
    catch (e) { console.error(`[observatory-ws] broadcast failed: ${e.message}`); }
  });
});

// Replayed to every new connection, newest first. An empty array is the same
// code path as "plugin not installed", so a page with no observations yet and a
// node-dash without the observatory behave identically.
// The window is a config value, and the recompute timer is 15 minutes. Without
// this a viewer changing the window would wait a quarter of an hour to see it.
// ws-relay announces generically; it names no plugin. Task `observatory-window`.
registerSettingsListener(() => {
  // RE-RUN, then rebroadcast. charts() reads STORED FACTS, and the window is
  // baked into a fact when its inference last ran — on a 15-minute cycle. Simply
  // rebroadcasting served the previous window's numbers and the frontier appeared
  // frozen no matter which window was selected. Only the two window-dependent
  // reach inferences are re-run; the rest are untouched and keep their cadence.
  try {
    // reach.mission reads observatory.window_days too (inferences.js:603), and
    // contribution().caps — the "why not further" line — is read from its global
    // fact. Without it that panel showed the PREVIOUS window's numbers for up to
    // 15 minutes, which is the panel the operator is looking at when they change
    // the window.
    for (const key of ['reach.ladder', 'reach.heard', 'reach.mission']) runInference(key);
  } catch (e) {
    console.error(`[observatory-ws] window recompute failed: ${e.message}`);
  }
  try { _broadcast?.({ type: 'charts', charts: charts() }); }
  catch (e) { console.error(`[observatory-ws] window refresh failed: ${e.message}`); }
});

registerConnectReplay(() => {
  try {
    return [
      {
        type: 'observations_replay',
        observations: recentObservations('reception', REPLAY_LIMIT).map(toMessage),
      },
      { type: 'relay_usage', relays: relayUsage() },
      { type: 'reach_model', reach: reachModel() },
      { type: 'mesh_links', links: meshLinks() },
      { type: 'missions', missions: missions() },
      { type: 'mission_activity', activity: missionRunner.state() },
      { type: 'charts', charts: charts() },
      // THE LOG, and the pipeline that writes it. `hooks` is the enumerable
      // answer to "what does this system execute and what does each claim to
      // do" — served so the page never has to infer it. Task `logs-feed`.
      { type: 'event_log', events: recentEventLog(300), hooks: listHooks() },
    ];
  } catch (e) {
    console.error(`[observatory-ws] replay failed: ${e.message}`);
    return [];
  }
});

/** The readable tail of a reverse-geocoded address: town, county.
 *
 *  The stored form is "Ash Lane, Winsford, TA24 7AD, Somerset, United Kingdom".
 *  A door list wants "Winsford, Somerset" — the street and the postcode are
 *  precision nobody is using, and the country is the same for all of them.
 *  Returns null rather than a placeholder when nothing is cached yet, so the
 *  column stays empty instead of filling with noise while the backfill runs. */
function shortPlace(address) {
  if (!address) return null;
  const parts = address.split(',').map(s => s.trim()).filter(Boolean);
  if (parts.length < 2) return parts[0] || null;
  const noCountry = parts.length > 2 ? parts.slice(0, -1) : parts;
  const postcodeish = s => /\d/.test(s) && s.length <= 9;
  const keep = noCountry.filter(s => !postcodeish(s));
  return keep.slice(-2).join(', ') || null;
}

/** The TOWN out of a reverse-geocoded address — what a map caption wants.
 *
 *  NOT shortPlace()'s first token, which is the street. Nominatim returns
 *  "Alexandra Road, St. Ives, TR26 2ET, Cornwall, United Kingdom" and
 *  "Rue des Prés, St. Pierre du Bois, GY7 9RZ, Guernsey" — the same shape with
 *  a different number of parts, so a fixed index picks the street in one and
 *  the county in the other.
 *
 *  Counted from the END instead: the last surviving part is always the region
 *  (Cornwall, Guernsey, Ceredigion) and the one before it is the town. Verified
 *  against every geocoded outlier in the cache — St. Ives, Torteval, Wychavon,
 *  St Peter Port, Nanpean — and it degrades to the single remaining part for
 *  the village-only addresses ("Horeb, SA44 4ND, Ceredigion") that have no
 *  street at all. */
function placeName(address) {
  if (!address) return null;
  const parts = address.split(',').map(s => s.trim()).filter(Boolean);
  // "United Kingdom" is the same for every node here and carries nothing.
  // Guernsey and Jersey are NOT dropped — there the country IS the location.
  const noCountry = parts.filter(s => s !== 'United Kingdom');
  const keep = noCountry.filter(s => !(/\d/.test(s) && s.length <= 9));
  if (!keep.length) return null;
  return keep.length >= 2 ? keep[keep.length - 2] : keep[0];
}

/** Current relay usage, heaviest first.
 *
 *  A pure read of stored facts — the inference already ran; this does not
 *  recompute on a page load. Provenance rides along (`at`, `evidence`) so the
 *  page can say when it was last worked out rather than implying it is live. */
// A RELAY AND A ROUTER ARE NOT THE SAME THING. Peter, 2026-08-04: "we are still
// treating routers and clients the same and they are all grouped into doors in
// the dashboard", and earlier: "repeaters are gold dust to us".
//
//   router — DECLARED role, configured to carry other people's traffic.
//   relay  — OBSERVED only. Any node can carry a packet once; it may never again.
//
// Measured: 6 declared routers carry 2865 of our completed routes (95.1%); 11
// observed relays carry 148 (4.9%), and 4 of those 11 are our own radios. The
// distinction is the dominant fact about our routing, so the page must be able
// to show it rather than lumping both under "Doors".
// Single home: node-kind.js. Was declared here TWICE (also at the old :831).
import { RELAY_ROLES } from './node-kind.js';

function roleMap() {
  const m = new Map();
  for (const r of db.prepare('SELECT num, role FROM nodes WHERE role IS NOT NULL').all()) {
    m.set(r.num, r.role);
  }
  return m;
}

function relayUsage() {
  const heard = lastHeardMap(), pos = positionMap(), roles = roleMap();
  const now = Math.floor(Date.now() / 1000);
  return facts('relay.usage')
    .map(f => ({
      relay:    f.entity,
      // NAME RESOLVED HERE, not in the browser. The page tried
      // this.nodes.find(...) and got 4 nodes — that list is FILTERED, so every
      // relay rendered as a raw number. It is also a BROWSER_CONTRACT breach:
      // a label is a display value and belongs to the server.
      label:    resolveNodeLabel(Number(f.entity)) || String(f.entity),
      place:    shortPlace(getCachedGeocode(Number(f.entity))),
      uses:     f.value?.uses ?? 0,
      targets:  f.value?.targets ?? 0,
      furthest_km: f.value?.furthest_km ?? null,
      bearing:  bearingFromHome(pos.get(Number(f.entity))?.lat, pos.get(Number(f.entity))?.lon),
      since:    sinceStr(heard.has(Number(f.entity)) ? now - heard.get(Number(f.entity)) : null),
      since_sec: heard.has(Number(f.entity)) ? now - heard.get(Number(f.entity)) : null,
      since_tone: sinceTone(heard.has(Number(f.entity)) ? now - heard.get(Number(f.entity)) : null),
      furthest_tone: furthestTone(f.value?.furthest_km ?? null),
      at:       f.ts,
      evidence: f.evidence_count,
      // Classification decided HERE, not in the browser (BROWSER_CONTRACT).
      // `kind` is what the page colours by; `role` is shown verbatim so a
      // junk value (B77: three nodes carry role "200.0") is visible rather
      // than silently folded into "relay".
      role:      roles.get(Number(f.entity)) ?? null,
      kind:      RELAY_ROLES.has(roles.get(Number(f.entity))) ? 'router'
               : roles.get(Number(f.entity)) === 'CLIENT_MUTE' ? 'never'
               : 'relay',
      is_router: RELAY_ROLES.has(roles.get(Number(f.entity))),
    }))
    .sort((a, b) => b.uses - a.uses);
}

/** The reach model, ready to render.
 *
 *  Server-computed per BROWSER_CONTRACT: the record, the ladder and the ranked
 *  frontier are all decided here, and the page places strings.
 *
 *  THE HEADLINE IS "AT LEAST". §4: silence is censored data, so a frontier is a
 *  lower bound on what we can reach, never a statement about what we cannot.
 *  Suspect distances (>200 km, §12) are excluded from the record and the
 *  frontier — a flag nobody reads is not a guard — but their count is reported
 *  so the exclusion is visible rather than silent. */
function reachModel() {
  const targeted = new Set(listObsTargets().map(x => x.num));
  const heard = lastHeardMap();
  const nowS = Math.floor(Date.now() / 1000);
  const targets = facts('reach.target');
  // HOW OLD IS ALL THIS? Peter, 2026-08-02: "if a traceroute was last done 4
  // days ago, then our entire page is dead and old data." Every panel here is
  // derived from traceroute_history, so the board must state the age of its
  // newest evidence rather than presenting five-day-old figures as current.
  const newest = targets.reduce(
    (mx, f) => Math.max(mx, f.value?.last_attempt || 0), 0) || null;
  const ladder  = facts('reach.ladder')[0]?.value ?? null;

  const usable = targets.filter(f => f.value?.verified && f.value?.km != null && !f.value?.suspect);
  const frontier = usable
    .sort((a, b) => b.value.km - a.value.km)
    .slice(0, 12)
    .map(f => ({
      target:  f.entity,
      label:   resolveNodeLabel(Number(f.entity)) || String(f.entity),
      km:      f.value.km,
      bearing: f.value.bearing ?? null,
      since:   sinceStr(heard.has(Number(f.entity)) ? nowS - heard.get(Number(f.entity)) : null),
      since_sec: heard.has(Number(f.entity)) ? nowS - heard.get(Number(f.entity)) : null,
      since_tone: sinceTone(heard.has(Number(f.entity)) ? nowS - heard.get(Number(f.entity)) : null),
      obs_target: targeted.has(Number(f.entity)),
      hits:    f.value.hits,
      attempts: f.value.attempts,
      // tab-observatory.html:426 divided hits/attempts and applied <0.1 itself.
      hit_rate: hitRateVerdict(f.value.hits, f.value.attempts).rate,
      hit_rate_tone: hitRateVerdict(f.value.hits, f.value.attempts).tone,
      last_ok: f.value.last_ok,
      // A place beats a callsign for judging a corridor: "St Ives, Cornwall"
      // says why the shot is hard in a way "Ives" never can. Trimmed to the
      // town-and-county tail — the street number is noise at this zoom.
      place:   shortPlace(getCachedGeocode(Number(f.entity))),
    }));

  // EVERY plottable target, not just the frontier's top 12: a radar showing a
  // dozen dots is a list with extra steps. Suspect distances stay out (§12).
  const plot = usable.map(f => ({
    target:  f.entity,
    label:   resolveNodeLabel(Number(f.entity)) || String(f.entity),
    km:      f.value.km,
    bearing: f.value.bearing,
    hits:    f.value.hits,
    attempts: f.value.attempts,
  })).filter(p => p.bearing != null);

  return {
    plot,
    home_lat: HOME.lat,
    home_lon: HOME.lon,
    record_km:    ladder?.record_km ?? null,
    record_at:    ladder?.record_at ?? null,
    rungs:        (ladder?.rungs ?? []).map(r => ({
      ...r,
      label: resolveNodeLabel(Number(r.target)) || String(r.target),
    })),
    frontier,
    verified:     targets.filter(f => f.value?.verified).length,
    targets:      targets.length,
    unverified:   targets.filter(f => !f.value?.verified).length,
    without_km:   targets.filter(f => f.value?.verified && f.value?.km == null).length,
    suspect:      targets.filter(f => f.value?.suspect).length,
    last_attempt: newest,
  };
}

/** The mission shortlist — what to try next, and why.
 *
 *  Ranking and reasons are the inference's (`reach.mission`); this resolves
 *  names and places and hands over a list. The summary row is separated out
 *  rather than being filtered away silently: the counts it carries are what
 *  stop a shortlist reading as "these are the only options". */
function missions() {
  // So the crosshair on each row can show its own state without the browser
  // holding any (BROWSER_CONTRACT).
  const targeted = new Set(listObsTargets().map(x => x.num));
  const heard = lastHeardMap();
  const nowM = Math.floor(Date.now() / 1000);
  const all = facts('reach.mission');
  const summary = all.find(f => f.entity === 'global')?.value ?? null;
  const list = all
    .filter(f => f.entity !== 'global' && f.value)
    .sort((a, b) => b.value.rank - a.value.rank)
    .map(f => ({
      target: f.entity,
      label:  resolveNodeLabel(Number(f.entity)) || String(f.entity),
      place:  shortPlace(getCachedGeocode(Number(f.entity))),
      km:     f.value.km,
      bearing: f.value.bearing ?? null,
      since:   sinceStr(heard.has(Number(f.entity)) ? nowM - heard.get(Number(f.entity)) : null),
      since_sec: heard.has(Number(f.entity)) ? nowM - heard.get(Number(f.entity)) : null,
      obs_target: targeted.has(Number(f.entity)),
      step_km: f.value.step_km ?? null,
      step_tone: stepTone(f.value.step_km ?? null),
      since_tone: sinceTone(heard.has(Number(f.entity)) ? nowM - heard.get(Number(f.entity)) : null),
      cls:    f.value.cls,
      reason: f.value.reason,
      attempts: f.value.attempts,
      hits:     f.value.hits,
      age_days: f.value.age_days,
    }));
  return { missions: list, summary };
}

/** The chart series. Display aggregation, assembled here rather than inferred —
 *  see docs/OBSERVATORY_CHARTS.md. `ladder` is reused from the existing fact and
 *  never recomputed.
 *
 *  Wrapped: a chart failing must degrade to an empty panel, not take the feed
 *  down with it. */

/** Answer-rate bands for the yield charts. Serves the RATE as well as the tone:
 *  the browser was dividing answers/attempts itself and then thresholding the
 *  result, so serving only a tone would leave half the decision behind.
 *
 *  Zero attempts is NOT a zero rate — it is no data, and must not paint red. */
const RATE_BANDS = [
  { min: 15, tone: 'success' },
  { min: 5,  tone: 'warning' },
  { min: 0,  tone: 'error'   },
];
// Three more thresholds found in tab-observatory.html during the Domain 2
// sweep. Templates hide this logic from a grep of the script files, which is
// how they survived — see docs/modules/signal-verdict.md.
//
//   :524  m.step_km > 50            -> warning / success
//   :594  r.since_sec < 86400/604800 -> success / muted / warning
//   :597  r.furthest_km > 150       -> primary / muted
//
// A STEP past proven ground is judged here because "how big a leap is too big"
// is the selector's own rule, not a rendering choice.
const BIG_STEP_KM   = 50;
const FAR_RELAY_KM  = 150;
const SINCE_BANDS = [
  { max: 86400,  tone: 'success' },   // within a day
  { max: 604800, tone: 'muted'   },   // within a week
  { max: null,   tone: 'warning' },   // longer, or never
];
function stepTone(km)     { return km == null ? 'muted' : km > BIG_STEP_KM ? 'warning' : 'success'; }
function furthestTone(km) { return km == null ? 'muted' : km > FAR_RELAY_KM ? 'primary' : 'muted'; }
function sinceTone(sec)   {
  if (sec == null) return 'muted';
  return (SINCE_BANDS.find(b => b.max == null || sec < b.max) ?? SINCE_BANDS[SINCE_BANDS.length - 1]).tone;
}

function withRateVerdict(row) {
  if (!row) return row;
  const attempts = Number(row.attempts) || 0;
  if (!attempts) return { ...row, rate_pct: null, tone: 'muted' };
  const pct  = 100 * (Number(row.answers) || 0) / attempts;
  const band = RATE_BANDS.find(b => pct >= b.min) ?? RATE_BANDS[RATE_BANDS.length - 1];
  return { ...row, rate_pct: +pct.toFixed(1), tone: band.tone };
}

function charts() {
  // ONE window for every series. Before this, `daily` and `bands` were 30 days
  // while `silence` and `distance` were all-time, with nothing on screen saying
  // so — four series read side by side, two of which were not comparable with
  // the other two. Task `observatory-window`.
  // Default 7, matching the stored value. It was 30 here and in boardVerdicts
  // while config held 7, so a missing key would have silently re-based the whole
  // board on a different window with nothing on screen saying so.
  // 30, matching config-api.js:32 and the COALESCE in inferences.js:285/393/603.
  // This read 7 while those read 30, so with the key absent charts()'s series
  // were 7-day while window_frontier_km/heard_km in the SAME object were 30-day.
  // The observatory-window task claimed to have fixed this and changed only two
  // of the four sites.
  const windowDays = Number(getConfig('observatory.window_days', 30)) || 0;
  const out = {
    ladder: [], record_km: null, daily: [], silence: [], distance: [], bands: [],
    window_days: windowDays, window_best_km: null, window_answered: 0,
    // Published so a later Domain 2 task can MARK the boundary on screen. Rates
    // before it are already suppressed server-side; this is for the label.
    failure_epoch: Number(getConfig('perf.failure_epoch', null)) || null,
  };
  try {
    const l = facts('reach.ladder')[0]?.value ?? null;
    // BOTH frontiers, labelled. record_km is the all-time historical best;
    // window_km is what we can do NOW and is the number worth chasing. Peter,
    // 2026-08-03: "if the farthest node heard in the last 7 days was 50km, then
    // our goal is to beat that."
    out.window_frontier_km   = l?.window_km ?? null;
    out.window_frontier_at   = l?.window_at ?? null;
    const hd = facts('reach.heard')[0]?.value ?? null;
    out.heard_km             = hd?.heard_km ?? null;
    out.window_heard_km      = hd?.window_heard_km ?? null;
    out.heard_nodes_window   = hd?.nodes_window ?? 0;
    out.heard_max_km_per_hop = hd?.max_km_per_hop ?? null;
    out.heard_rejected       = hd?.rejected_implausible ?? 0;
    out.ladder = (l?.rungs ?? []).map(r => ({
      ts: r.ts, km: r.km,
      label: resolveNodeLabel(Number(r.target)) || String(r.target),
    }));
    out.record_km = l?.record_km ?? null;
  } catch (e) { console.error(`[observatory-ws] ladder series failed: ${e.message}`); }
  try { out.daily = attemptsByDay(windowDays); }
  catch (e) { console.error(`[observatory-ws] daily series failed: ${e.message}`); }
  // ANSWER-RATE VERDICT. app-observatory.js:300,307 divided answers/attempts
  // itself and then applied >=15/>=5 to pick a colour — a judgement about
  // discovery YIELD, made in the presentation layer.
  //
  // Deliberately NOT in signal-verdict.js: that module judges how good a LINK
  // is. An answer rate is a different kind of fact with a different owner, and
  // this chart builder is its only consumer. One owner each is what SSOT means;
  // a single module holding every band table in the app is just a dumping ground.
  try {
    // Ordered here, not in SQL: the buckets are a scale (best to worst) and the
    // page must not have to know their order to draw them correctly.
    const order = ['direct RF', '< 24h', '< 7d', 'silent 7d+'];
    const by = new Map(answerRateBySilence(windowDays).map(r => [r.bucket, r]));
    out.silence = order.filter(k => by.has(k)).map(k => withRateVerdict(by.get(k)));
  } catch (e) { console.error(`[observatory-ws] silence series failed: ${e.message}`); }
  try { out.distance = answerRateByDistance(windowDays).map(withRateVerdict); }
  catch (e) { console.error(`[observatory-ws] distance series failed: ${e.message}`); }
  // Rate per day SPLIT BY BAND — the aggregate `daily` series above cannot tell a
  // change in target mix from a change in performance, and that hid a fall from
  // ~58% to ~7% at under 25 km across three weeks. Task `rate-by-band-by-day`.
  try { out.bands = rateByBandByDay(windowDays); }
  catch (e) { console.error(`[observatory-ws] bands series failed: ${e.message}`); }
  // The furthest reached INSIDE the window — a different fact from record_km,
  // which stays all-time because it is the thing to beat. Windowed to 7 days the
  // record would read ~92 km and imply we had gone backwards.
  // The three verdicts. Server-computed with a stated basis — the browser makes
  // no decisions and neither should the operator's eyes. Task `board-verdicts`.
  // Interventions inside the window, so the page can mark them on the traces:
  // "yield fell after we changed X" becomes visible rather than remembered.
  try { out.interventions = interventions(windowDays); }
  catch (e) { console.error(`[observatory-ws] interventions failed: ${e.message}`); }
  try { out.board = boardVerdicts(windowDays); }
  catch (e) { console.error(`[observatory-ws] board verdicts failed: ${e.message}`); }
  // The STATE band's table. Wrapped like every other series: a failure here
  // degrades to an empty table, it does not take the board down.
  try { out.nodes = nodeTable(windowDays); }
  catch (e) { console.error(`[observatory-ws] node table failed: ${e.message}`); }
  // 30 days regardless of the viewer's window: "have we gained ground" is a
  // question about the campaign, not about the last few hours.
  try { out.contribution = contribution(30); }
  catch (e) { console.error(`[observatory-ws] contribution failed: ${e.message}`); }
  try {
    const w = windowBestKm(windowDays);
    out.window_best_km  = w.km;
    out.window_answered = w.answered;
  } catch (e) { console.error(`[observatory-ws] window best failed: ${e.message}`); }
  return out;
}

/** Observed links with both endpoints placed — the mesh map's geometry.
 *
 *  Capped and ordered by traffic so the heaviest corridors survive the cut: a
 *  map that silently drops its busiest link would be worse than one that admits
 *  it is showing the top N. */
function meshLinks() {
  const all = facts('link.observed').map(f => f.value).filter(Boolean);
  const links = all.sort((a, b) => b.count - a.count).slice(0, 400).map(l => ({
    a: l.a, b: l.b, a_lat: l.a_lat, a_lon: l.a_lon, b_lat: l.b_lat, b_lon: l.b_lon,
    km: l.km, count: l.count,
  }));

  // LABEL THE OUTLIERS ONLY. Naming all 200-odd nodes would be a wall of text
  // over a map; naming the far ones tells you which corridor you are looking at.
  // Chosen by distance from us — the near cluster is where we live and needs no
  // caption, and the point of the map is the reach.
  const seen = new Map();
  for (const l of links) {
    for (const [n, lat, lon] of [[l.a, l.a_lat, l.a_lon], [l.b, l.b_lat, l.b_lon]]) {
      if (seen.has(n)) continue;
      seen.set(n, { node: n, lat, lon, km: haversine(HOME.lat, HOME.lon, lat, lon) });
    }
  }

  // ONE LABEL PER CLUSTER, NOT PER NODE — and this is the whole point of the
  // marks. The first attempt named nodes and printed six Guernsey street
  // addresses stacked on one another ("Rue du Closel 176km", "Terramar Court
  // 177km", "Les Vieux Beaucamps 179km" …), which is six ways of saying
  // "Guernsey" and one unreadable smudge. At 180 km the map cannot separate
  // them anyway.
  //
  // Greedy from the furthest outward: the first node in a neighbourhood names
  // it, and the rest only raise its count. CLUSTER_KM is a map-legibility
  // figure, not a mesh one — 15 km is roughly where two dots stop being
  // distinguishable at this zoom.
  const CLUSTER_KM = 15;
  const clusters = [];
  for (const n of [...seen.values()].filter(n => n.km > 90).sort((a, b) => b.km - a.km)) {
    const c = clusters.find(c => haversine(c.lat, c.lon, n.lat, n.lon) < CLUSTER_KM);
    if (c) { c.count++; continue; }
    clusters.push({ ...n, count: 1 });
  }

  const marks = clusters.slice(0, 12).map(n => ({
    node: n.node, lat: n.lat, lon: n.lon, km: Math.round(n.km), nodes: n.count,
    // Place beats callsign on a map — "St. Ives" locates you, "Ives" does not.
    // Falls back to the label, then the raw num; never a placeholder.
    label: placeName(getCachedGeocode(n.node))
           || resolveNodeLabel(n.node) || String(n.node),
  }));

  // EVERY PLOTTED NODE, CLASSIFIED HERE. The page was drawing 92 identical grey
  // dots, so the map showed where the mesh is and nothing about what it does for
  // us. Peter, 2026-08-02: "we need some node plot point colour differences so we
  // can more easily read the map and what it's telling us."
  //
  // Classification is a decision, so it is the server's (BROWSER_CONTRACT). The
  // browser gets a class name and a weight and paints them.
  //
  //   relay    — carried our traffic. A door. 57 of 92.
  //   endpoint — we have a verified route to it, but nothing has ever relayed
  //              through it. A leaf. 35 of 92.
  //   seen     — on the map through someone else's route only. Currently zero,
  //              and that is expected rather than a bug: link.observed is built
  //              FROM our traceroute routes, so every endpoint is by definition
  //              in a route we obtained. The class exists because the moment a
  //              second evidence source lands (passive relay_node, §7b) it will
  //              start filling, and a map that silently reclassified them as
  //              endpoints would be lying.
  //
  // `weight` is the door's share of relayed traffic, 0..1, linear on log(uses)
  // — the busiest relay is not fifty times more important than the quietest, it
  // is one or two rungs up, and a linear scale would draw one huge dot and
  // ninety-one specks.
  const usage = new Map(facts('relay.usage').map(f => [f.entity, f.value?.uses ?? 0]));
  const reached = new Set(
    facts('reach.target').filter(f => f.value?.verified).map(f => f.entity));
  const maxUses = Math.max(1, ...usage.values());

  const nodes = [...seen.values()].map(n => {
    const key = String(n.node);
    const uses = usage.get(key) ?? 0;
    return {
      node: n.node, lat: n.lat, lon: n.lon, km: Math.round(n.km),
      cls: uses > 0 ? 'relay' : (reached.has(key) ? 'endpoint' : 'seen'),
      uses,
      weight: uses > 0 ? Math.log1p(uses) / Math.log1p(maxUses) : 0,
      label: resolveNodeLabel(n.node) || String(n.node),
      place: placeName(getCachedGeocode(n.node)),
    };
  });

  const legend = [
    { cls: 'relay',    text: 'relayed for us', count: nodes.filter(n => n.cls === 'relay').length },
    { cls: 'endpoint', text: 'route verified', count: nodes.filter(n => n.cls === 'endpoint').length },
    { cls: 'seen',     text: 'seen only',      count: nodes.filter(n => n.cls === 'seen').length },
  ];

  return { total: all.length, links, marks, nodes, legend };
}

/** BEARING and SINCE — the two columns every table was missing.
 *
 *  Peter, 2026-08-02: "something missing from every table is 1: bearing,
 *  2: since." Both are display values, so both are computed here rather than in
 *  the browser (BROWSER_CONTRACT), and `since` ships as the STRING the column
 *  shows plus the raw seconds the page needs to tint it.
 *
 *  Short by design — "6h", "3d" — because the column has to fit the data, not
 *  the other way round. */
function sinceStr(sec) {
  if (sec == null || !Number.isFinite(sec)) return '—';
  const h = sec / 3600;
  if (h < 1)  return `${Math.max(1, Math.round(sec / 60))}m`;
  if (h < 48) return `${Math.round(h)}h`;
  return `${Math.round(h / 24)}d`;
}

/** THE BOARD'S NODE TABLE — the STATE band of docs/APP_ROLE.md.
 *
 *  Peter, 2026-08-04: "we should still summarise / use the data from nodes in
 *  node-dash as a quick way to see what nodes we have so we dont have to switch
 *  screens ... show the top n nodes in a table, which consumes less space than
 *  node cards would."
 *
 *  CONTEXT, NOT SCORE. This is node-dash's own data, summarised. It measures
 *  nothing about this app — that is the CONTRIBUTION band's job, and conflating
 *  them is the error APP_ROLE.md exists to prevent.
 *
 *  Live AND placed, furthest first. Furthest-first rather than lead-ranked is a
 *  deliberate first cut: the eye reads the edge, which is where the work is.
 *
 *  EVERY DISPLAY DECISION IS MADE HERE. The session that stripped the last
 *  threshold out of public/ finished hours before this was written; a table that
 *  shipped `km > record ? 'lead' : ''` in a template would undo it on day one. */
function nodeTable(windowDays, limit = 15) {
  const now  = Math.floor(Date.now() / 1000);
  const win  = Number(windowDays) > 0 ? Number(windowDays) : 3650;
  const from = now - win * 86400;

  // Contact evidence: OUR OWN receptions. nodeinfo is excluded on purpose — it
  // is a BLE nodedb replay (db.js:638), not proof a packet reached us.
  const heardRows = new Set();
  for (const q of ['SELECT DISTINCT from_num n FROM relay_observation',
                   'SELECT DISTINCT from_num n FROM messages WHERE from_num IS NOT NULL',
                   'SELECT DISTINCT num n FROM signal_history']) {
    try { for (const r of db.prepare(q).all()) if (r.n) heardRows.add(r.n); }
    catch { /* table may be absent on a fresh install — absence is not an error */ }
  }
  const probes = new Map();
  for (const r of db.prepare(
    `SELECT to_num n, COUNT(*) c, SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) ok
       FROM traceroute_history GROUP BY n`).all()) probes.set(r.n, r);

  const record = Number(facts('reach.ladder')[0]?.value?.record_km) || null;

  const rows = db.prepare(
    `SELECT num, short_name, role, lat, lon, alt, last_heard, hops, snr
       FROM nodes
      WHERE lat IS NOT NULL AND lat <> 0 AND last_heard > ?`).all(from)
    .map(n => ({ n, km: haversine(HOME.lat, HOME.lon, n.lat, n.lon) }))
    // >400 km is laundered MQTT traffic, not radio-earned. §12.
    .filter(x => x.km != null && x.km <= 400)
    .sort((a, b) => b.km - a.km)
    .slice(0, Math.max(1, Number(limit) || 15))
    .map(({ n, km }) => {
      const p    = probes.get(n.num);
      const tries = p?.c ?? 0;
      const hasPacket = heardRows.has(n.num);
      const age  = n.last_heard ? now - n.last_heard : null;
      const mute = n.role === 'CLIENT_MUTE';
      // THE JUDGEMENT: past the envelope, alive, and unworked. Written as a
      // sentence here — the page must never assemble an explanation out of
      // numbers, the same rule the mission table already follows.
      const past = record != null && km > record;
      const lead = past && tries <= 2;
      let lead_reason = null;
      if (lead) {
        lead_reason = `${km.toFixed(1)} km is ${Math.round(km - record)} km past the record, `
          + `heard ${sinceStr(age)} ago, and `
          + (tries === 0 ? 'has never been probed' : `has been probed only ${tries}×`)
          + (hasPacket ? ' — we hold real packets from it' : ' — position only, no packet yet');
      }
      return {
        num: n.num,
        label: resolveNodeLabel(n.num) || '!' + (n.num >>> 0).toString(16).slice(-4),
        km: +km.toFixed(1),
        az: bearingFromHome(n.lat, n.lon),
        place: shortPlace(getCachedGeocode(n.num)),
        alt: n.alt ?? null,
        role: n.role || null,
        // CLIENT_MUTE is called out because it can never be a door, however
        // close or loud — it does not rebroadcast, by declaration.
        // TOKENS THE BROWSER ACTUALLY DEFINES. This emitted 'gold' and 'dim',
        // neither of which is in app-helpers.js TONE, so toneCls() fell through
        // to muted and a declared ROUTER painted identically to a plain CLIENT —
        // the one distinction the field exists to carry. Caught by review; I had
        // "verified" it by reading the payload, not the rendered badge.
        role_tone: mute ? 'muted' : (RELAY_ROLE_SET.has(n.role) ? 'warning' : 'muted'),
        is_router: RELAY_ROLE_SET.has(n.role),
        can_be_door: !mute,
        hops: n.hops ?? null,
        heard_sec: age,
        heard: sinceStr(age),
        // sinceTone, NOT heardTone: heardTone's 30-min/1-h bands answer "is this
        // node active right now" for the node list. Here the window is 7 days and
        // the question is "is it alive at all", so every row past an hour came
        // back `error` and the column said nothing. Same scale as the mission and
        // relay tables, which ask the same question — one concept, one table.
        heard_tone: sinceTone(age),
        snr: n.snr ?? null,
        probes: tries,
        answered: p?.ok ?? 0,
        // `packet` = a reception WE logged. `nodedb` = we only have a position.
        evidence: hasPacket ? 'packet' : 'nodedb',
        lead,
        lead_reason,
      };
    });

  return { rows, limit: Number(limit) || 15, window_days: Number(windowDays) || 0, record_km: record };
}

/** WHAT HAS THIS ENGINE ACTUALLY PRODUCED? — the CONTRIBUTION band.
 *
 *  Peter, 2026-08-04: "but is it actually doing anything ?!" and, when the
 *  answer turned out to be a shell query I had run myself, "and why is all of
 *  that ONLY visible to you ?"
 *
 *  That was the real defect. The board showed the engine was BUSY — loop
 *  running, 46 attempts an hour, yield 8% — and nothing about whether it was
 *  WORKING. "0 past the record in 30 days" is the most important fact about
 *  this app and it existed nowhere on screen.
 *
 *  docs/APP_ROLE.md already says "finding nothing is a result". That rule was
 *  applied to the workers and the board itself left exempt.
 *
 *  NOTHING HERE NEEDS THE ATTRIBUTION LEDGER. traceroute_history has held all
 *  of it the whole time; I over-scoped by drawing all four mockup cards as
 *  AWAITING LEDGER. Only the "did we cause it, or did it arrive anyway" tiers
 *  genuinely need new capture. */
function contribution(windowDays) {
  const now  = Math.floor(Date.now() / 1000);
  const win  = Number(windowDays) > 0 ? Number(windowDays) : 30;
  const from = now - win * 86400;

  const record = Number(facts('reach.ladder')[0]?.value?.record_km) || null;
  const pos = new Map(db.prepare(
    'SELECT num, lat, lon, short_name FROM nodes WHERE lat IS NOT NULL AND lat <> 0').all()
    .map(r => [r.num, r]));

  // A node's FIRST-EVER completed route is the only thing that is genuinely new
  // ground. Re-verifying a node we already knew proves the mesh still works; it
  // does not extend anything.
  const firstOk = db.prepare(
    `SELECT to_num n, MIN(ts) t FROM traceroute_history WHERE status='ok' GROUP BY to_num`).all();
  const fresh = firstOk.filter(r => r.t > from);
  // PLAUSIBILITY CEILING. Without it ONE laundered self-reported position flips
  // the headline to a green "Gaining ground" — §12's "EA1HTF claims 1003 km".
  // Every sibling path filters (nodeTable 400, boardVerdicts/answerRateByDistance
  // 250, mission selection at ceiling_km); this one did not. The DB holds 128
  // placed nodes beyond 250 km today, so the failure was one reply away.
  const PLAUSIBLE_KM = 250;
  const all = fresh.map(r => {
    const p = pos.get(r.n);
    return p ? { km: haversine(HOME.lat, HOME.lon, p.lat, p.lon), nm: p.short_name, t: r.t } : null;
  }).filter(Boolean);
  const suspect = all.filter(r => r.km > PLAUSIBLE_KM).length;
  const placed = all.filter(r => r.km <= PLAUSIBLE_KM).sort((a, b) => b.km - a.km);

  const att = db.prepare(
    `SELECT COUNT(*) n, SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) ok
       FROM traceroute_history WHERE ts > ?`).get(from);

  const beyond = record != null ? placed.filter(r => r.km > record).length : null;
  const furthest = placed[0] ?? null;
  const median = placed.length ? placed[Math.floor(placed.length / 2)].km : null;

  // WHY NOT FURTHER — served as the selector's own numbers, so the board can
  // say what is capping it instead of leaving the reader to ask.
  const m = facts('reach.mission').find(f => f.entity === 'global')?.value ?? {};

  // THE NAMES, not just the count. Peter, 2026-08-04: "it has not mined a single
  // sucessful node" — it had mined 11 in 3 days, and the app never said so. A
  // count in a card is not evidence; a list of what was reached is.
  const recent = all
    .filter(r => r.t > now - 7 * 86400 && r.km <= PLAUSIBLE_KM)
    .sort((a, b) => b.t - a.t)
    .slice(0, 12)
    .map(r => ({ km: +r.km.toFixed(1), label: r.nm ?? null, ts: r.t,
                 past_record: record != null && r.km > record }));

  return {
    window_days: win,
    record_km: record,
    recent_first_contacts: recent,
    // Stated because they cannot move any frontier and would otherwise inflate
    // the headline count silently.
    recent_unplaced: fresh.filter(r => r.t > now - 7 * 86400).length - all.filter(r => r.t > now - 7 * 86400).length,
    attempts: att.n,
    answered: att.ok || 0,
    new_routes: fresh.length,
    new_routes_placed: placed.length,
    // Stated because the distance figures are drawn only from the placed ones.
    new_routes_unplaced: fresh.length - placed.length,
    beyond_record: beyond,
    furthest_km: furthest ? +furthest.km.toFixed(1) : null,
    furthest_label: furthest?.nm ?? null,
    furthest_short_by: (furthest && record != null) ? +(record - furthest.km).toFixed(1) : null,
    median_km: median != null ? +median.toFixed(1) : null,
    cost_per_new_route: fresh.length ? Math.round(att.n / fresh.length) : null,
    // The verdict, written here. The page must not decide what this means.
    gaining: beyond != null && beyond > 0,
    suspect_beyond_plausible: suspect,
    // `record` is null until reach.ladder has produced a fact. Without this the
    // else branch rendered "null new routes past the null km record" inside a
    // red panel, on every fresh install.
    verdict: record == null
      ? `${att.n.toLocaleString()} attempts — no verified route on record yet, so there is nothing to measure against`
      : beyond === 0
        ? `${att.n.toLocaleString()} attempts, ${fresh.length} nodes reached for the first time — but NONE past the furthest verified route (${record} km)`
        : `${beyond} new route${beyond === 1 ? '' : 's'} past the furthest verified route (${record} km)`,
    caps: {
      window_km: m.window_km ?? null,
      bar_km: m.bar_km ?? null,
      ceiling_km: m.ceiling_km ?? null,
      skipped_beyond_window: m.skipped_beyond_window ?? null,
      skipped_silent: m.skipped_silent ?? null,
      max_silence_days: m.max_silence_days ?? null,
      strategy: m.strategy ?? null,
    },
  };
}

// Declared relay roles, for the role TONE only — never as a door filter. Measured
// 2026-08-04: this set captures 19 of the 99 nodes that have actually relayed for
// us, so filtering doors on it discards 80.8% of them. See docs/APP_ROLE.md.
const RELAY_ROLE_SET = RELAY_ROLES;   // second copy in this same file — now an alias

/** Bearing FROM us, degrees. Duplicated from the catalogue for the same reason
 *  haversine is: this layer must not import domain calculations. */
function bearingFromHome(lat, lon) {
  if (lat == null || lon == null || HOME.lat == null || HOME.lon == null) return null;
  const r = Math.PI / 180;
  const y = Math.sin((lon - HOME.lon) * r) * Math.cos(lat * r);
  const x = Math.cos(HOME.lat * r) * Math.sin(lat * r)
          - Math.sin(HOME.lat * r) * Math.cos(lat * r) * Math.cos((lon - HOME.lon) * r);
  return Math.round((Math.atan2(y, x) / r + 360) % 360);
}

/** Great-circle km. Duplicated from the catalogue on purpose: this file must not
 *  import domain calculations, and an inference must not be imported for its
 *  arithmetic — that coupling is how the engine's boundary starts to leak. */
function haversine(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(a)));
}

// RECOMPUTED ON BOOT, then on a slow timer. `relay.usage` is a batch inference
// over all history — cheap at this size (12,268 evidence rows, ~40 ms) but not
// something to run per packet, and the answer moves slowly: a new relay appears
// only when a traceroute completes through it.
//
// Deferred past startup so a slow query cannot delay the port opening, and
// wrapped so a failure degrades the doors panel rather than the process.
function recompute(broadcast) {
  try {
    for (const key of ['relay.usage', 'reach.target', 'reach.ladder', 'reach.heard', 'link.observed', 'reach.mission']) {
      const r = runInference(key);
      console.log(`[observatory] ${r.key}: ${r.facts} facts from ${r.rows} evidence rows`);
    }
    // ONLY WHEN NON-ZERO. MQTT arrivals never enter the store (§3a) — they are
    // dropped at the mapper — but a silent discard is indistinguishable from a
    // quiet channel. Today this number is zero and the line never prints; the
    // day a gateway starts bridging, it does.
    const dropped = mqttDiscarded();
    if (dropped) console.log(`[observatory] ${dropped} MQTT arrivals discarded since boot — not radio hops`);

    broadcast?.({ type: 'relay_usage', relays: relayUsage() });
    broadcast?.({ type: 'reach_model', reach: reachModel() });
    broadcast?.({ type: 'mesh_links', links: meshLinks() });
    const list = missions();
    broadcast?.({ type: 'missions', missions: list });
    broadcast?.({ type: 'charts', charts: charts() });

    // FEED THE ACTUATOR. The runner never fetches — it is handed the shortlist
    // and works it. This file is already an allowed importer of the engine; the
    // runner deliberately is not, so the coupling lives here.
    missionRunner.setQueue(list.missions);
    // Seed what was already known BEFORE any mission ran, so the first route
    // does not report the whole existing mesh as newly discovered.
    // Replay recent attempts so the panel is populated on a cold start. Only
    // the yagi-dispatched ones: those are the discovery runner's, and a
    // passive-tracer trace of whatever just arrived is not a mission.
    try {
      const rows = recentAimedTraceroutes(25);
      missionRunner.seedRecent(rows.map(r => ({
        target: String(r.to_num),
        label:  resolveNodeLabel(r.to_num) || String(r.to_num),
        place:  shortPlace(getCachedGeocode(r.to_num)),
        km: null, step_km: null, az: r.rotator_az,
        seeded: true,
        ok: r.status === 'ok',
        hops: null, hops_back: null, found: [],
        error: r.status === 'ok' ? null : 'no reply',
        finished: r.ts,
      })));
    } catch (e) {
      console.error(`[observatory-ws] recent replay failed: ${e.message}`);
    }

    missionRunner.seed({
      relays: facts('relay.usage').map(f => f.entity),
      links:  facts('link.observed').map(f => f.entity),
    });
  } catch (e) {
    console.error(`[observatory] relay.usage failed: ${e.message}`);
  }
}

registerWsWiring(({ broadcast }) => {
  // DISABLED 2026-08-17 (`observatory.enabled`, default false). Peter: "I do not
  // want it taking up resources and populating the database." recompute() wrote
  // ~1,218 obs_fact rows every 15 minutes — ~120k/day with the per-packet
  // observations. The WIRING still registers (registerWsWiring is read once at
  // attach time, so skipping it here would be unrecoverable without a restart);
  // what stops is the work and the feeds.
  if (!getConfig('observatory.enabled', false)) return;

  setTimeout(() => recompute(broadcast), timing().first_recompute_ms);
  // Settable (discovery.recompute_min): selection latency is a timing that
  // changes what the operator sees, so it needs a bounded knob like the rest.
  // Read once at wiring — a live re-read would need the interval torn down and
  // rebuilt, which is not worth it for a value nobody changes mid-session.
  const recomputeMin = Number(discoveryConfig().recompute_min) || 15;
  setInterval(() => recompute(broadcast), recomputeMin * 60_000);

  // Live activity: every state change, pushed. This is the panel Peter asked
  // for — "what it's done, doing right now, and whether a discovery is in
  // progress" — so it must not wait on the 15-minute recompute.
  missionRunner.on('activity', (activity) => {
    try { broadcast({ type: 'mission_activity', activity }); }
    catch (e) { console.error(`[observatory-ws] activity broadcast failed: ${e.message}`); }
  });

  // Started after the first recompute has had a chance to fill the queue.
  setTimeout(() => missionRunner.start(), timing().runner_start_ms);
});
