// The catalogue — every value this system works out rather than is told.
//
// Peter, 2026-08-02: "the hooks should be a seperate file, so it's easy to see
// our calculated functions in 1 place, the file will grow as we think of new
// things to get / extract. so each will be a small func that does one thing."
//
// Read this file top to bottom and you have seen everything node-dash infers.
// That is the whole point of it being one file, and it is worth protecting: an
// inference that lives anywhere else is invisible.
//
// THIS FILE IS DOMAIN CODE. It knows what a bearing is, what a node is, what a
// relay is. The engine (observatory.js) knows none of that and must never learn
// — the split is what keeps the engine testable and reusable, and it is enforced
// by tests/test_observatory_boundary.mjs, which permits exactly two importers of
// the engine: the composition root, and this catalogue.
//
// ─── THE RULES EVERY INFERENCE OBEYS ────────────────────────────────────────
//
// 1. PURE. A function of the evidence it is handed and nothing else. No database
//    access inside, no clock, no randomness, no network.
//
//    This is not a style preference and it is the rule most likely to be broken
//    for convenience. An inference that reaches for the database itself cannot
//    be recomputed over history, cannot be tested without a database, and
//    silently destroys the retroactive property that is the entire reason the
//    registry exists (MESH_REACH_SPEC §7f). If an inference needs more evidence,
//    it DECLARES it and the runner fetches it.
//
// 2. SMALL, AND ONE THING. If it does two things it is two inferences.
//
// 3. `null` IS A REAL ANSWER. "Not enough evidence yet" is returned, never
//    thrown and never faked as a zero — a plausible wrong value is worse than an
//    absent one.
//
// 4. NO PROVENANCE BY HAND. The runner stamps what produced a value, when, from
//    how much evidence. An inference that writes its own provenance can launder
//    itself as a fact.
//
// 5. GRADUATION. When a function outgrows a page — peak-RSSI bearing estimation
//    with windowing and outlier rejection will — it moves to its own file and is
//    imported and registered here. This file stays the index either way.
//
// ─── THE CATALOGUE ──────────────────────────────────────────────────────────
//
//   relay.usage     the doors — traffic carried, targets behind, furthest reach
//   reach.target    per target: km, bearing, attempts, hits, verified
//   reach.ladder    one global fact: every moment the frontier moved
//   link.observed   every witnessed node-to-node hop, both ends placed
//   reach.mission   what to try next, and why — the memory the prober lacks
//
// All five are BATCH and spend no airtime at all: four read obs_v_traceroute, a
// view over five weeks of traceroute history that already existed, and
// reach.mission reads `nodes` LEFT JOINed to it so that targets never attempted
// are in the pool rather than invisible.
//
// This file was created EMPTY by task `observatory-inference-catalogue-boundary`
// so the boundary test was correct BEFORE anything pressed on it. Widening a
// boundary test to admit code that already exists is how boundaries die.
//
// STILL MISSING: the antenna-bearing estimator. Its capture half is not an
// inference — recording where the antenna pointed is an observation — and the
// estimate is blocked on DATA, not code: 305 recorded bearings span two distinct
// azimuths because the rotator has not moved (B54). An estimator over that would
// confidently place every unplaced node at 119°.
import { registerInference } from './observatory.js';

/** "3h ago" / "6d ago" — how long a node has been silent, for the reason string.
 *  Written here because a reason is a display value and the browser must not
 *  assemble one (BROWSER_CONTRACT). Pure: it is handed a duration, not a clock. */
function fmtSilence(sec) {
  if (!Number.isFinite(sec)) return 'never';
  const h = sec / 3600;
  if (h < 1)  return 'within the hour';
  if (h < 48) return `${Math.round(h)}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

// ─── relay.usage ────────────────────────────────────────────────────────────
//
// WHICH RELAYS CARRY OUR TRAFFIC, AND HOW MUCH OF THE MESH SITS BEHIND EACH.
// The doors of MESH_REACH_SPEC §7a: our reach is not a radius, it is a tree with
// a few load-bearing doors, and 57 relays carry every route we have ever
// completed. If T4 goes off air, 79 targets go with it — a fact worth seeing
// before it happens rather than after.
//
// EVIDENCE IS DECLARED, NOT FETCHED. The inference cannot query without
// destroying its own purity, and the engine cannot query on its behalf without
// learning what a route is. So the SQL lives here, with the inference that owns
// it, and the engine executes it understanding nothing.
//
// json_each expands the route ARRAY inside the JSON payload into one row per
// hop — so a nested array inside a JSON column inside a view over a table nobody
// migrated becomes a graph, in SQL, with no parsing in JavaScript. Verified on
// SQLite 3.53.2.
//
// BOTH DIRECTIONS. route_back is included because the way home is not the way
// out: 23 relays appear ONLY on return paths (§7b). They carried our traffic and
// nothing ever chose them.
//
// 0xffffffff IS EXCLUDED. The broadcast address appears in stored route fields
// and is not a node — it ranked eighth in the door list on first run, with 49
// targets "behind" it, which is meaningless. MESH_REACH_SPEC §7b flags it as a
// question about our own parsing rather than a relay to go and find; until that
// is settled it must not be presented as a door.
registerInference({
  key:  'relay.usage',
  deps: [],
  mode: 'batch',   // recomputed from all history; cheap enough at this size
  evidence: `
    SELECT j.value AS relay, o.entity AS target, n.lat AS lat, n.lon AS lon,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon
    FROM obs_v_traceroute o
    LEFT JOIN nodes n ON n.num = CAST(o.entity AS INTEGER)
    , json_each(o.data ->> '$.route') j
    WHERE o.data ->> '$.status' = 'ok' AND j.value <> 4294967295
    UNION ALL
    SELECT j.value, o.entity, n.lat, n.lon,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat'),
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon')
    FROM obs_v_traceroute o
    LEFT JOIN nodes n ON n.num = CAST(o.entity AS INTEGER)
    , json_each(o.data ->> '$.route_back') j
    WHERE o.data ->> '$.status' = 'ok' AND j.value <> 4294967295
  `,
  /** Pure: rows in, facts out. No database, no clock, no randomness.
   *
   *  `targets` is what makes a relay a door — how much becomes unreachable if
   *  it stops. `uses` is how much traffic it has actually carried, which is a
   *  different question and the two disagree often enough to be worth keeping
   *  apart. */
  run(rows) {
    const byRelay = new Map();
    for (const r of rows) {
      const relay = String(r.relay);
      let e = byRelay.get(relay);
      if (!e) byRelay.set(relay, e = { uses: 0, targets: new Set(), furthest: null });
      e.uses += 1;
      if (r.target != null) e.targets.add(String(r.target));
      // FURTHEST TARGET BEHIND THIS DOOR — the reason a relay matters, as
      // opposed to how busy it is. A relay carrying a lot of local chatter and
      // one holding open the Cornwall corridor look identical in `uses`.
      // Suspect distances (>200 km, §12) are excluded here too, so a bad
      // self-reported position cannot make a door look more important than it is.
      if (r.lat != null && r.lon != null && r.home_lat != null && r.home_lon != null) {
        const km = greatCircleKm(r.home_lat, r.home_lon, r.lat, r.lon);
        if (km <= 200 && (e.furthest == null || km > e.furthest)) e.furthest = km;
      }
    }
    return [...byRelay].map(([entity, e]) => ({
      entity,
      value: {
        uses: e.uses,
        targets: e.targets.size,
        furthest_km: e.furthest == null ? null : Math.round(e.furthest * 10) / 10,
      },
      // No confidence offered: this is a count of what was observed, not an
      // estimate. A made-up 1.0 would imply a judgement nothing here made.
      confidence: null,
      evidence_count: e.uses,
    }));
  },
});

// ─── reach.target ───────────────────────────────────────────────────────────
//
// HOW FAR WE HAVE VERIFIABLY REACHED, PER TARGET. The headline this project
// resolves to (MESH_REACH_SPEC §1a: "at the end of all calculations the single
// important value will be in km").
//
// Home comes through the EVIDENCE, not from a config read inside run(). Reading
// it here would make the calculation impure and untestable without a database
// for the sake of two numbers. Carried on every row is mildly redundant and
// exactly correct.
//
// The distance is computed in run() rather than in SQL. SQLite has the trig
// (3.53.2 has radians/sin/asin/pi) so either would work, but an inference that
// only relabels its evidence is not really a calculation — and haversine over
// plain numbers is the easiest thing in the world to test.
const HAVERSINE_R_KM = 6371;
/** Initial great-circle bearing, degrees from true north. Pure. */
function bearingDeg(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const y = Math.sin((lon2 - lon1) * rad) * Math.cos(lat2 * rad);
  const x = Math.cos(lat1 * rad) * Math.sin(lat2 * rad)
          - Math.sin(lat1 * rad) * Math.cos(lat2 * rad) * Math.cos((lon2 - lon1) * rad);
  return (Math.atan2(y, x) / rad + 360) % 360;
}
function greatCircleKm(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return HAVERSINE_R_KM * 2 * Math.asin(Math.min(1, Math.sqrt(a)));
}

registerInference({
  key:  'reach.target',
  deps: [],
  mode: 'batch',
  evidence: `
    SELECT o.entity                                                   AS target,
           COUNT(*)                                                   AS attempts,
           SUM(CASE WHEN o.data ->> '$.status' = 'ok' THEN 1 ELSE 0 END) AS hits,
           MAX(CASE WHEN o.data ->> '$.status' = 'ok' THEN o.ts END)  AS last_ok,
           MAX(o.ts)                                                  AS last_attempt,
           n.lat                                                      AS lat,
           n.lon                                                      AS lon,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon
    FROM obs_v_traceroute o
    LEFT JOIN nodes n ON n.num = CAST(o.entity AS INTEGER)
    GROUP BY o.entity
  `,
  /** Pure. Rows in, facts out.
   *
   *  A TARGET WITH NO HIT IS STILL RECORDED, with verified:false and its attempt
   *  count. MESH_REACH_SPEC §4: silence is censored data, so the stored fact is
   *  "verified reach >= X", never "unreachable". 335 targets have never once
   *  answered across 5,046 attempts and dropping them would hide the most
   *  important number in the project.
   *
   *  A TARGET WITH NO POSITION GETS km:null, not 0. It was still reached; we
   *  simply cannot say how far. Only 84 of 104 verified targets have a position,
   *  so this is common and must not read as "zero kilometres". */
  run(rows) {
    return rows.map(r => {
      const km = (r.lat != null && r.lon != null && r.home_lat != null && r.home_lon != null)
        ? Math.round(greatCircleKm(r.home_lat, r.home_lon, r.lat, r.lon) * 10) / 10
        : null;
      const bearing = (r.lat != null && r.lon != null && r.home_lat != null && r.home_lon != null)
        ? Math.round(bearingDeg(r.home_lat, r.home_lon, r.lat, r.lon))
        : null;
      return {
        entity: String(r.target),
        value: {
          km,
          // Bearing FROM US to the target, computed from stored positions. Not
          // to be confused with the antenna bearing recorded on a reception
          // (docs/modules/observations.md) — that one is a measurement, this is
          // geometry. Keeping the two apart matters: one can verify the other.
          bearing,
          attempts:     r.attempts,
          hits:         r.hits,
          verified:     r.hits > 0,
          last_ok:      r.last_ok ?? null,
          last_attempt: r.last_attempt ?? null,
          // §12: a self-reported position can be wrong, and a km headline will
          // launder it into a record. EA1HTF claims 1003 km and arrives at
          // -44 dBm. Flagged here so nothing downstream has to remember.
          suspect: km != null && km > 200,
        },
        confidence: null,
        evidence_count: r.attempts,
      };
    });
  },
});

// ─── reach.ladder ───────────────────────────────────────────────────────────
//
// EVERY MOMENT THE FRONTIER MOVED. One fact, entity 'global', because a ladder
// is a property of the whole record rather than of any node.
//
// It is the product's narrative (MESH_REACH_SPEC §1a) and it says something
// uncomfortable that a single headline number hides: the whole climb from 5 km
// to 95 km happened in about eighteen hours on 24 June, then 181.6 km the next
// morning — and the frontier has moved 7.5 km in the five weeks since. A system
// that iterates without learning plateaus, and this is the shape of the plateau.
//
// SUSPECT DISTANCES ARE EXCLUDED from the ladder, not merely flagged. A record
// is a claim, and §12 is explicit that a km headline will launder a bad
// self-reported position into one. A flag on a row nobody reads is not a guard.
registerInference({
  key:  'reach.ladder',
  deps: [],
  mode: 'batch',
  evidence: `
    SELECT o.ts                                                       AS ts,
           o.entity                                                   AS target,
           n.lat                                                      AS lat,
           n.lon                                                      AS lon,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon,
           COALESCE((SELECT CAST(value AS INTEGER) FROM config WHERE key = 'observatory.window_days'), 30) AS s_window_days,
           (SELECT MAX(strftime('%s','now')))                         AS now_ts
    FROM obs_v_traceroute o
    JOIN nodes n ON n.num = CAST(o.entity AS INTEGER)
    WHERE o.data ->> '$.status' = 'ok' AND n.lat IS NOT NULL AND n.lon IS NOT NULL
    ORDER BY o.ts
  `,
  /** Pure. A running maximum over hits in time order, PLUS the frontier inside
   *  the current window.
   *
   *  THE RECORD ALONE MADE THE BOARD UNFALSIFIABLE. Peter, 2026-08-03: "the board
   *  is stagnant and looks to me to be identical to how it looked 3 days ago. it
   *  is just a historical record… might be that 189.1 will never change and our
   *  sights are too high."
   *
   *  He is right. Measuring today against an all-time maximum admits exactly two
   *  outcomes — unchanged, or once a month a new record — and the antennas have
   *  MOVED since 189.1 km was set on 2026-07-04. A month-old number taken with a
   *  different physical setup is history, not a target.
   *
   *  So both are published. `record_km` stays all-time, because it is the honest
   *  historical best and must not be quietly lowered. `window_km` is what we can
   *  actually do NOW, and is the number worth chasing: beat the last 7 days.
   */
  run(rows) {
    let best = 0;
    const rungs = [];
    for (const r of rows) {
      if (r.home_lat == null || r.home_lon == null) continue;
      const km = Math.round(greatCircleKm(r.home_lat, r.home_lon, r.lat, r.lon) * 10) / 10;
      if (km > 200) continue;                 // §12 — excluded, not flagged
      if (km <= best) continue;
      best = km;
      rungs.push({ ts: r.ts, target: String(r.target), km });
    }
    if (!rungs.length) return null;           // null is a real answer

    // Windowed frontier — a plain maximum, NOT a running one. Inside a window we
    // want the best reached in that period, not a ratchet inherited from before it.
    // days = 0 means all time, and then the two figures coincide by definition.
    const days = Number(rows[0].s_window_days) || 0;
    const now  = Number(rows[0].now_ts) || 0;
    const cut  = days > 0 ? now - days * 86400 : 0;
    let winKm = null, winAt = null, winTarget = null, winCount = 0;
    for (const r of rows) {
      if (r.ts < cut) continue;
      if (r.home_lat == null || r.home_lon == null) continue;
      const km = Math.round(greatCircleKm(r.home_lat, r.home_lon, r.lat, r.lon) * 10) / 10;
      if (km > 200) continue;
      winCount++;
      if (winKm == null || km > winKm) { winKm = km; winAt = r.ts; winTarget = String(r.target); }
    }
    return [{
      entity: 'global',
      value: {
        rungs,
        record_km: best,
        record_at: rungs[rungs.length - 1].ts,
        window_days:      days,
        window_km:        winKm,
        window_at:        winAt,
        window_target:    winTarget,
        window_answered:  winCount,
      },
      confidence: null,
      evidence_count: rows.length,
    }];
  },
});

// ─── reach.heard ────────────────────────────────────────────────────────────
//
// THE OTHER HALF OF REACH. Peter, 2026-08-03: "last heard and last reply to a
// traceroute are different things, we should have both of them and both are
// equally as valuable and should be considered in our logic."
//
// `reach.ladder` measures a ROUND TRIP we initiated. This measures ONE-WAY: a
// packet — any port, text, position, telemetry, nodeinfo — that originated at
// that node and reached us. Hearing a node proves a path TO us exists, which is
// the strongest prior we hold for whether a traceroute might come back.
//
// WHY THE DISTANCE NEEDS A GUARD, and the answer is not "trust it". Measured
// 2026-08-03: furthest heard in 7 days was 932.4 km over 7 hops = 133 km/hop,
// with a cluster of nodes at 428.0 / 427.9 / 444.2 km that looks like one distant
// mesh reaching us through somebody's MQTT bridge. Our radios set
// `ignore_mqtt: true`, so nothing arrives at US over MQTT — but other nodes
// bridge it IN and then relay it to us over LoRa, and `transport_mechanism`
// describes only the last leg. The reception is real; the distance is not
// radio-earned.
//
// MAX_KM_PER_HOP is therefore a HEURISTIC and is published so it can be argued
// with rather than hidden. Calibration: the 189.1 km record went via a relay
// 13.1 km away, so a single leg covered ~176 km — real, and it must survive.
// 456 km/hop must not.
const MAX_KM_PER_HOP = 200;

registerInference({
  key:  'reach.heard',
  deps: [],
  mode: 'batch',
  // OUR OWN PACKET LOG, not the radio's nodedb. This read nodes.last_heard and
  // nodes.hops — and db.js:638 states plainly that node_info/node_update is "a
  // BLE nodedb replay, NOT reception evidence". The inference that exists to
  // measure receptions was sourced from the one table documented as not being
  // evidence of one. Ledger B82.
  //
  // relay_observation carries PER-PACKET hop_start/hop_limit, so hops_used is
  // measured per reception instead of guessed from a single nodedb scalar.
  evidence: `
    SELECT r.from_num                                                 AS num,
           n.lat                                                      AS lat,
           n.lon                                                      AS lon,
           MAX(r.ts)                                                  AS last_heard,
           MIN(CASE WHEN r.hop_start IS NOT NULL AND r.hop_limit IS NOT NULL
                    THEN r.hop_start - r.hop_limit END)               AS hops,
           COUNT(*)                                                   AS packets,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon,
           COALESCE((SELECT CAST(value AS INTEGER) FROM config WHERE key = 'observatory.window_days'), 30) AS s_window_days,
           (SELECT MAX(strftime('%s','now')))                         AS now_ts
    FROM relay_observation r
    JOIN nodes n ON n.num = r.from_num
    WHERE n.lat IS NOT NULL AND n.lon IS NOT NULL AND n.lat <> 0
    GROUP BY r.from_num
  `,
  /** Pure. Furthest node heard, all time and inside the window. */
  run(rows) {
    if (!rows.length) return null;
    const days = Number(rows[0].s_window_days) || 0;
    const now  = Number(rows[0].now_ts) || 0;
    const cut  = days > 0 ? now - days * 86400 : 0;

    let allKm = null, allNum = null, winKm = null, winNum = null, winAt = null;
    let directKm = null, directNum = null;
    let heardAll = 0, heardWin = 0, rejected = 0;

    for (const r of rows) {
      if (r.home_lat == null || r.home_lon == null) continue;
      const km = Math.round(greatCircleKm(r.home_lat, r.home_lon, r.lat, r.lon) * 10) / 10;
      if (!Number.isFinite(km)) continue;
      // FAILS CLOSED. This was `Number(r.hops) || 0` then `hops > 0 && ...`, so
      // an UNKNOWN hop count skipped the guard entirely — and nodes.hops was
      // null for most nodes, so it rejected 19 of 616 and published 1050.9 km.
      // Unknown is not zero; unknown is exactly the case that must be rejected.
      // "A guard that fails open is worse than no guard." Ledger B81.
      if (r.hops == null) { rejected++; continue; }
      const hops = Number(r.hops);
      if (!Number.isFinite(hops) || hops < 0) { rejected++; continue; }
      // hops === 0 is a genuine DIRECT reception: nothing relayed it, so there
      // is nothing to launder and no per-hop test applies.
      if (hops > 0 && km / hops > MAX_KM_PER_HOP) { rejected++; continue; }
      heardAll++;
      if (hops === 0 && (directKm == null || km > directKm)) { directKm = km; directNum = r.num; }
      if (allKm == null || km > allKm) { allKm = km; allNum = r.num; }
      if (r.last_heard >= cut) {
        heardWin++;
        if (winKm == null || km > winKm) { winKm = km; winNum = r.num; winAt = r.last_heard; }
      }
    }
    return [{
      entity: 'global',
      value: {
        heard_km:        allKm,
        heard_num:       allNum,
        // DIRECT RF — 0 relays, our own radio. A different fact from `heard_km`
        // (which may have crossed five hops) and from the verified-route record.
        // docs/APP_ROLE.md keeps the three apart; conflating them is how a
        // relayed 308 km contact gets read as a 308 km radio path.
        direct_km:       directKm,
        direct_num:      directNum,
        basis:           'relay_observation packet log; per-packet hop_start-hop_limit',
        window_days:     days,
        window_heard_km: winKm,
        window_heard_num: winNum,
        window_heard_at: winAt,
        nodes_all:       heardAll,
        nodes_window:    heardWin,
        // Published, not hidden: the guard changes the headline number and a
        // reader is entitled to know how many nodes it removed and on what rule.
        max_km_per_hop:  MAX_KM_PER_HOP,
        rejected_implausible: rejected,
      },
      confidence: null,
      evidence_count: rows.length,
    }];
  },
});

// ─── link.observed ──────────────────────────────────────────────────────────
//
// EVERY NODE-TO-NODE HOP WE HAVE EVER WITNESSED, with both endpoints placed.
// MESH_REACH_SPEC §7e — Peter: "when we have found a node that is relaying, we
// can see which node was relayed to it and therefore it's location… to stretch
// the 'spiderweb' overlay on a map… we will end up with the data for a mesh
// map."
//
// A route is a CHAIN OF EDGES, not a pair of endpoints, and we have been storing
// them since June without reading them that way: `us -> T4 -> fir -> TE 5 ->
// L5-3 -> Ives` is five observed links.
//
// BOTH DIRECTIONS, because the way home is not the way out — 23 relays appear
// only on return paths.
//
// The chain is assembled in run() rather than by a self-join on hop index. The
// SQL for that is a CTE joined to itself on idx+1 per route, which is harder to
// read and no faster at this size — and the terminators (us at one end, the
// target at the other) have to be spliced on in code anyway.
registerInference({
  key:  'link.observed',
  deps: [],
  mode: 'batch',
  evidence: `
    SELECT o.id                              AS route,
           CAST(o.entity AS INTEGER)         AS target,
           tn.lat                            AS target_lat,
           tn.lon                            AS target_lon,
           j.key                             AS idx,
           CAST(j.value AS INTEGER)          AS node,
           hn.lat                            AS lat,
           hn.lon                            AS lon,
           0                                 AS reversed,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon
    FROM obs_v_traceroute o
    LEFT JOIN nodes tn ON tn.num = CAST(o.entity AS INTEGER)
    , json_each(o.data ->> '$.route') j
    LEFT JOIN nodes hn ON hn.num = CAST(j.value AS INTEGER)
    WHERE o.data ->> '$.status' = 'ok' AND j.value <> 4294967295
    UNION ALL
    SELECT o.id, CAST(o.entity AS INTEGER), tn.lat, tn.lon,
           j.key, CAST(j.value AS INTEGER), hn.lat, hn.lon, 1,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat'),
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon')
    FROM obs_v_traceroute o
    LEFT JOIN nodes tn ON tn.num = CAST(o.entity AS INTEGER)
    , json_each(o.data ->> '$.route_back') j
    LEFT JOIN nodes hn ON hn.num = CAST(j.value AS INTEGER)
    WHERE o.data ->> '$.status' = 'ok' AND j.value <> 4294967295
    ORDER BY route, reversed, idx
  `,
  /** Pure. Chains in, links out.
   *
   *  Each link is keyed on its sorted node pair, so A->B and B->A are ONE link
   *  observed twice rather than two links. Direction is a property of a
   *  traversal, not of a radio path.
   *
   *  A link is emitted only when BOTH ends are placed — an unplaceable endpoint
   *  cannot be drawn, and inventing a position for it is exactly the laundering
   *  §12 warns about. Links with a missing end are counted and reported so the
   *  omission is visible rather than silent. */
  run(rows) {
    const US = 646426545;   // our OMNI; the chain's near terminator
    const chains = new Map();
    for (const r of rows) {
      const key = `${r.route}:${r.reversed}`;
      let c = chains.get(key);
      if (!c) chains.set(key, c = { target: r.target, target_lat: r.target_lat,
                                    target_lon: r.target_lon, reversed: r.reversed,
                                    home_lat: r.home_lat, home_lon: r.home_lon, hops: [] });
      c.hops.push({ node: r.node, lat: r.lat, lon: r.lon });
    }

    const links = new Map();
    let unplaceable = 0;
    for (const c of chains.values()) {
      const us     = { node: US, lat: c.home_lat, lon: c.home_lon };
      const target = { node: c.target, lat: c.target_lat, lon: c.target_lon };
      // Outbound runs us -> hops -> target; the return leg runs the other way.
      const chain = c.reversed ? [target, ...c.hops, us] : [us, ...c.hops, target];
      for (let i = 0; i < chain.length - 1; i++) {
        const a = chain[i], b = chain[i + 1];
        if (a.node === b.node) continue;
        if (a.lat == null || a.lon == null || b.lat == null || b.lon == null) { unplaceable++; continue; }
        const [lo, hi] = a.node < b.node ? [a, b] : [b, a];
        const id = `${lo.node}-${hi.node}`;
        const e = links.get(id);
        if (e) { e.count++; continue; }
        links.set(id, {
          count: 1,
          a: lo.node, b: hi.node,
          a_lat: lo.lat, a_lon: lo.lon,
          b_lat: hi.lat, b_lon: hi.lon,
          km: Math.round(greatCircleKm(lo.lat, lo.lon, hi.lat, hi.lon) * 10) / 10,
        });
      }
    }
    if (!links.size) return null;
    void unplaceable;
    return [...links].map(([id, v]) => ({
      entity: id,
      value: v,
      confidence: null,
      evidence_count: v.count,
    }));
  },
});

// ─── reach.mission ──────────────────────────────────────────────────────────
//
// WHICH TARGET TO TRY NEXT, AND WHY. The memory MESH_REACH_SPEC §2 says the
// prober does not have: "the machine is not selecting; it is iterating."
//
// Peter, 2026-08-02: "why is everything blocked by something else meaning that
// this will never be completed?" — a fair challenge, and the honest answer is
// that §9 was mis-framed. It was treated as a block on the whole Missions
// panel. It is not. node-dash ALREADY dispatches traceroutes itself
// (traceroute.js:128, passive-tracer.js:122 — 21,793 over five weeks, from both
// radios). No new authority is needed to govern sending that is already
// happening ungoverned. Only the BROADCAST CALLOUT is contested, and that is
// one instrument of three.
//
// This inference spends no airtime whatsoever. It ranks; it does not send.
//
// EVIDENCE STARTS FROM `nodes`, NOT FROM THE TRACEROUTE VIEW, and that is the
// whole point. A LEFT JOIN is the difference between "which of the targets we
// have tried deserves another go" and "what have we never looked at". Measured
// 2026-08-02: 213 positioned nodes have NEVER been attempted once, 39 of them
// beyond the 189.1 km record — while 423 attempts went to a single node with no
// position that has never answered. The pool the prober never saw is where the
// information is.
registerInference({
  key:  'reach.mission',
  deps: [],
  mode: 'batch',
  evidence: `
    SELECT n.num                                                      AS target,
           n.lat                                                      AS lat,
           n.lon                                                      AS lon,
           n.last_heard                                               AS last_heard,
           COUNT(th.id)                                               AS attempts,
           SUM(CASE WHEN th.status = 'ok' THEN 1 ELSE 0 END)          AS hits,
           MAX(CASE WHEN th.status = 'ok' THEN th.ts END)             AS last_ok,
           MAX(th.ts)                                                 AS last_attempt,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lat') AS home_lat,
           (SELECT CAST(value AS REAL) FROM config WHERE key = 'home.lon') AS home_lon,
           (SELECT MAX(strftime('%s','now'))) 					      AS now_ts,
           -- SETTINGS ARRIVE AS EVIDENCE, NOT AS A CALL. This inference is pure
           -- and the boundary test enforces it, so it cannot reach getConfig().
           -- Same trick as home.lat above. COALESCE gives the default in SQL, so
           -- an unset key can never produce a null that silently disables a rule.
           COALESCE((SELECT value ->> '$.strategy'            FROM config WHERE key = 'discovery'), 'ladder') AS s_strategy,
           COALESCE((SELECT value ->> '$.window_km'           FROM config WHERE key = 'discovery'), 25)   AS s_window_km,
           COALESCE((SELECT value ->> '$.attempts_per_target' FROM config WHERE key = 'discovery'), 6)    AS s_attempts,
           COALESCE((SELECT value ->> '$.cooldown_min'        FROM config WHERE key = 'discovery'), 30)   AS s_cooldown_min,
           COALESCE((SELECT value ->> '$.max_silence_days'    FROM config WHERE key = 'discovery'), 14)   AS s_max_silence,
           COALESCE((SELECT CAST(value AS INTEGER) FROM config WHERE key = 'observatory.window_days'), 30) AS s_window_days,
           COALESCE((SELECT value ->> '$.proven_min_hits'     FROM config WHERE key = 'discovery'), 3)    AS s_proven_hits,
           COALESCE((SELECT value ->> '$.proven_min_rate'     FROM config WHERE key = 'discovery'), 10)   AS s_proven_rate,
           COALESCE((SELECT value ->> '$.new_node_hours'      FROM config WHERE key = 'discovery'), 48)   AS s_new_hours,
           ni.first_heard                                             AS first_heard,
           COALESCE((SELECT value ->> '$.mode'                FROM config WHERE key = 'discovery'), 'auto') AS s_mode,
           (SELECT value ->> '$.pinned'                       FROM config WHERE key = 'discovery')        AS s_pinned,
           -- PROVEN CONTACT, as evidence. The ceiling was a hardcoded 250 and
           -- so excluded the furthest node we have actually received packets
           -- from — Peter: "you are not even using the node with the know proven
           -- distance in the nodes list". A distance we have DEMONSTRATED is not
           -- implausible by definition, so the ceiling must follow it.
           COALESCE((SELECT CAST(value ->> '$.heard_km' AS REAL) FROM obs_fact
                      WHERE key = 'reach.heard' AND entity = 'global'
                      ORDER BY ts DESC LIMIT 1), 0)                   AS s_proven_km,
           -- HAVE WE ACTUALLY RECEIVED PACKETS FROM THIS NODE? Peter,
           -- 2026-08-04: "we are supposed to treat ANY packet received from a
           -- node as contact verified." A node whose packets reach us but which
           -- has never completed a route is the single best lead the app can
           -- hold: contact proven, route unproven — exactly the gap it exists to
           -- close. This was nowhere in the selector.
           (SELECT COUNT(*) FROM relay_observation ro WHERE ro.from_num = n.num) AS packets,
           -- The Observatory's OWN target flag. Not nodeinfo.favourite, which
           -- means "pin to my sidebar" and is set on our own local units.
           COALESCE(ni.obs_target, 0)                                 AS obs_target,
           -- THE EXCLUSION THE LOOP CANNOT SEE. The WHERE clause below removes
           -- unpositioned nodes before any counter exists, so the only honest
           -- place to count them is here, in the evidence itself. 331 nodes on
           -- 2026-08-03 (174 heard within max_silence_days) -- the largest
           -- exclusion of all, and it appeared in no funnel segment.
           -- Declared as evidence rather than queried inside run(), so the
           -- inference stays pure.
           (SELECT COUNT(*) FROM nodes u
             WHERE u.lat IS NULL OR u.lon IS NULL OR u.lat = 0)         AS unpositioned
    FROM nodes n
    LEFT JOIN nodeinfo ni ON ni.num = n.num
    LEFT JOIN traceroute_history th ON th.to_num = n.num
    WHERE n.lat IS NOT NULL AND n.lon IS NOT NULL AND n.lat <> 0
      AND n.num NOT IN (
        SELECT DISTINCT from_num FROM traceroute_history WHERE from_num IS NOT NULL
      )
    GROUP BY n.num
  `,
  /** Pure: rows in, facts out. `now_ts` arrives IN the evidence rather than
   *  being read from a clock here. The catalogue may not call one at all — the
   *  boundary test greps for it, so ages are computed against a timestamp SQL
   *  supplied, which also means a recompute over history stays repeatable.
   *
   *  OUR OWN RADIOS ARE EXCLUDED VIA `from_num`, not via `nodes.device`. A
   *  mission to traceroute the radio doing the tracerouting is not a mission,
   *  but the first attempt used `n.device IS NULL` and that is a different
   *  thing entirely: `device` is the MAC of the radio that HEARD the node, so
   *  it is set on 903 nodes and the filter cut the pool from 601 to 3, with a
   *  0 km "record" to match. `from_num` is the addressee of a traceroute reply
   *  and is only ever one of ours — measured: TA2o, TA2y, GARG, nothing else.
   *
   *  EVERY MISSION CARRIES ITS REASON AS A STRING, written here. The browser
   *  must not assemble an explanation out of numbers (BROWSER_CONTRACT), and a
   *  ranked list with no stated reason is a magic number wearing a table. */
  run(rows) {
    if (!rows.length) return null;
    const now = Number(rows[0].now_ts) || 0;
    const HOME = { lat: rows[0].home_lat, lon: rows[0].home_lon };
    if (HOME.lat == null || HOME.lon == null) return null;

    // SETTABLE FROM THE DASHBOARD (docs/DISCOVERY_STRATEGY.md). These were
    // hardcoded, and the 24 h cooldown was the specific reason the queue drifted
    // out to 133 km steps: it retired every good candidate after a single
    // attempt, so selection had nothing near to work on.
    const STRATEGY  = String(rows[0].s_strategy || 'ladder');
    const WINDOW_KM = Number(rows[0].s_window_km) || 25;
    const MAX_TRIES = Number(rows[0].s_attempts) || 6;
    const COOLDOWN  = (Number(rows[0].s_cooldown_min) || 30) * 60;
    const MAX_SILENT = (Number(rows[0].s_max_silence) || 14) * 86_400;
    const PROVEN_HITS = Number(rows[0].s_proven_hits) || 3;
    const PROVEN_RATE = (Number(rows[0].s_proven_rate) || 10) / 100;
    const NEW_WINDOW  = (Number(rows[0].s_new_hours)  || 48) * 3600;
    const MODE      = String(rows[0].s_mode || 'auto');
    const PINNED    = rows[0].s_pinned != null ? Number(rows[0].s_pinned) : null;
    // §12: beyond this a self-reported position is not evidence, it is a
    // claim. 250 rather than the record's 200 because a MISSION may legitimately
    // aim past the current frontier — the point is to beat it — but a node
    // claiming 1,681 km is not a target, it is a bad coordinate.
    // 250 was a hardcoded guess at "beyond this a position is laundered". It
    // also silently excluded every node we have PROVEN contact with beyond it —
    // the app held proof of a 308.6 km reception and would never once have
    // looked at that node. reach.heard's heard_km is itself guarded (per-packet
    // hops, fails closed), so it is a demonstrated distance, not a claim.
    const PROVEN_KM  = Number(rows[0]?.s_proven_km) || 0;
    const CEILING_KM = Math.max(250, Math.ceil(PROVEN_KM));

    const scored = [];
    const skipped = { cooling: 0, suspect: 0, exhausted: 0, beyond_window: 0, silent: 0, unclassified: 0 };

    // The record is computed from the same rows, not passed in: an inference
    // that took the record as a dependency would rank against a stale one on
    // the run where the record itself moved.
    //
    // PROVEN GROUND, not just the record number. Every node we have actually
    // reached is a place a packet of ours has demonstrably arrived, and the
    // set of them is the shape of what we can do — the single furthest one is a
    // summary of it, not a substitute for it.
    // PROVEN GROUND MEANS RELIABLY REACHED, NOT REACHED ONCE.
    //
    // This admitted any node that had ever answered, and the furthest such node
    // is the 189.1 km record holder — 1 hit in 63 attempts, 1.6%. So the window
    // measured from 189 km and admitted candidates out to 214 km, a band the
    // distance chart shows answering 0.0-1.3% across 2,088 attempts. One lucky
    // packet on 4 July was dragging the entire search 90 km past anything real.
    //
    //   ever answered once        84 nodes, furthest 189.1 km
    //   3+ hits AND >=10% of tries 31 nodes, furthest  95.2 km   <- reliable
    //
    // 95.2 km is exactly where the wall is. THE RECORD IS UNCHANGED — reach.ladder
    // still reports 189.1 km, because "furthest we have reached" and "furthest we
    // can rely on" are different claims and both are true.
    let record = 0;
    // THE BAR THE SEARCH ACTUALLY AIMS AT. Peter, 2026-08-03: "the ultimate
    // target is 189.1km, but in our current window, the best is 92km, that is
    // what we should be looking to beat and not 189.1km."
    //
    // The all-time record was set on 2026-07-04 with antennas that have since
    // MOVED, and nothing since has come close. Ranking against it sent DISC into
    // the 187-234 km band, which answers 0.0-1.3% across 2,088 measured attempts.
    // Just past the window's best sits in 75-100 km, which answers 20.9% (n=549).
    const WINDOW_DAYS = Number(rows[0].s_window_days) || 0;
    const winCut = WINDOW_DAYS > 0 ? now - WINDOW_DAYS * 86400 : 0;
    let windowBest = 0;
    const proven = [{ lat: HOME.lat, lon: HOME.lon }];   // we are, trivially, reachable
    for (const r of rows) {
      if (!r.hits) continue;
      const km = greatCircleKm(HOME.lat, HOME.lon, r.lat, r.lon);
      if (km > 200) continue;                            // §12 — a claim, not evidence
      if (km > record) record = km;                      // the record counts every hit
      // Reached INSIDE the window — last_ok is already in the evidence.
      if (r.last_ok && Number(r.last_ok) >= winCut && km > windowBest) windowBest = km;
      if (r.hits < PROVEN_HITS) continue;
      if (r.attempts && (r.hits / r.attempts) < PROVEN_RATE) continue;
      proven.push({ lat: r.lat, lon: r.lon });
    }

    // FLOORED AT PROVEN GROUND. A self-referential bar can ratchet DOWNWARDS: a
    // poor window lowers the bar, which selects easier targets, which keeps the
    // window low. The bar may never fall below what we already reach reliably.
    const reliableKm = Math.max(0, ...proven.map(q => greatCircleKm(HOME.lat, HOME.lon, q.lat, q.lon)));
    const bar = Math.max(windowBest, reliableKm);

    /** How far past the nearest node we have ACTUALLY REACHED.
     *
     *  THE METRIC THAT MATTERS, and raw distance from home is not it. Peter,
     *  2026-08-02: "what I am expecting to see is the 189km increase, if it's
     *  not then we are not making use of all of that data we have?"
     *
     *  He was right and this is the correction. Ranked by distance from home,
     *  the runner spent every attempt on 233-234 km nodes in Cheshire and
     *  Bedfordshire — about 100 km past anything we have ever touched, in
     *  corridors where no path has ever been demonstrated. Meanwhile Sen1 sits
     *  208 km out and just 21 km past Ives, which we verify at 187.7 km, and
     *  GA3 sits 213 km out and 37 km past the Guernsey relays.
     *
     *  On the headline number those are 25 km apart. As propositions they are
     *  nothing alike: one extends a working corridor by a hop, the other is a
     *  leap into the dark. The step is what separates them, and it is computable
     *  from data we have held for five weeks. */
    const stepKm = (lat, lon) => {
      let best = Infinity;
      for (const q of proven) {
        const d = greatCircleKm(lat, lon, q.lat, q.lon);
        if (d < best) best = d;
      }
      return best;
    };

    for (const r of rows) {
      const km = Math.round(greatCircleKm(HOME.lat, HOME.lon, r.lat, r.lon) * 10) / 10;

      // AN EXPLICIT CHOICE OUTRANKS EVERY AUTOMATIC EXCLUSION, including the
      // §12 distance ceiling. Found in Phase 4: a node starred at 333 km never
      // reached the queue because the ceiling test ran first, which defeats the
      // point of choosing it. A traceroute does not care whether the target's
      // self-reported position is right, and the RECORD is protected
      // separately — reach.ladder excludes suspect distances outright, so a
      // reply from a badly-placed node still cannot move the frontier.
      const isPinned = PINNED != null && Number(r.target) === PINNED;
      const isTarget = Number(r.obs_target) === 1;

      if (!isPinned && !isTarget && km > CEILING_KM) { skipped.suspect++; continue; }

      // IS THE NODE EVEN ALIVE? This is the strongest predictor we have and it
      // was going unused, while `last_heard` sat in the evidence already
      // selected. Measured across all 21,864 stored attempts:
      //
      //   heard on direct RF   26.1%      heard within 7d    7.0%
      //   heard within 24h     16.0%      silent over 7d     1.8%
      //
      // A 14x spread — far larger than any distance effect. MESH_REACH_SPEC §3
      // said so all along: "passive reception is free evidence and must be
      // mined first... it is proof the node is alive and roughly where, which
      // is what makes an attempt worth spending."
      //
      // Measured on the shortlist this replaces: only 4 of 14 entries had been
      // heard within 24 h. The rest were 4-33 days silent, and that is where
      // the budget was going while 40+ attempts produced nothing.
      const silentFor = r.last_heard ? (now - Number(r.last_heard)) : Infinity;
      if (!isPinned && !isTarget && silentFor > MAX_SILENT) { skipped.silent++; continue; }

      // Tiered rather than smooth: the measured curve is a cliff between "today"
      // and "last week", not a gentle decay, so the score should be too.
      const liveScore = silentFor <= 86_400   ? 400
                      : silentFor <= 3*86_400 ? 220
                      : silentFor <= 7*86_400 ?  90
                      :                          20;
      const attempts = Number(r.attempts) || 0;
      const hits     = Number(r.hits) || 0;
      const lastAtt  = r.last_attempt ? Number(r.last_attempt) : null;
      const ageDays  = lastAtt ? Math.floor((now - lastAtt) / 86_400) : null;
      if (lastAtt != null && (now - lastAtt) < COOLDOWN) { skipped.cooling++; continue; }

      let cls = null, reason = null, rank = 0;

      // SMALLEST STEP FIRST, not greatest distance. A 21 km extension of a
      // proven corridor outranks a 100 km leap into a direction we have never
      // reached, even though the leap has the bigger headline number.
      const step = Math.round(stepKm(r.lat, r.lon) * 10) / 10;

      // Your choices also bypass the WINDOW, but still respect the COOLDOWN.
      // Without that guard, pinning plus a 180 s interval is twenty traceroutes
      // an hour at one stranger's node — pursuit turning into harassment.
      //
      // THE WINDOW. A ladder climbs one rung at a time: a candidate is only
      // eligible if it sits within WINDOW_KM of ground we have actually
      // reached, and the window ratchets forward when the record moves. Without
      // it, ranking by smallest step still walks outward as near candidates go
      // into cooldown — measured at 106-133 km before this existed.
      //
      // `portfolio` keeps the old behaviour so a deliberate long shot is still
      // possible from the dashboard, without a deploy.
      if (!isPinned && !isTarget && STRATEGY === 'ladder' && step > WINDOW_KM) {
        skipped.beyond_window++; continue;
      }

      // SMALLEST-STEP-FIRST WAS THE WRONG OBJECTIVE FOR THIS APP. It maximises
      // the chance of a reply, which walks the queue toward near, chatty nodes —
      // measured over 30 days: 21,202 attempts, 51 first-ever routes, ZERO past
      // the record, median 68 km. docs/APP_ROLE.md: the app exists to push the
      // envelope, and a step score of max(0, 300 - step*2) is zero for anything
      // more than 150 km past proven ground, so the furthest leads always lost.
      //
      // Step is kept as a TIEBREAK — a shorter leap is still likelier — but it
      // no longer decides. What decides is how far past the bar the node is, and
      // whether its packets already reach us.
      const stepScore = Math.max(0, 300 - step * 2);
      // How far past the bar, capped so one absurd position cannot dominate.
      const pastScore = Math.max(0, Math.min(400, km - bar)) * 2;
      // CONTACT PROVEN, ROUTE UNPROVEN — the best lead there is.
      const contactScore = Number(r.packets) > 0 ? 400 : 0;

      if (isPinned) {
        cls = 'pinned';
        reason = `pinned — worked ahead of everything else (${Math.round(step)} km past the nearest node we have reached`
          + (km > CEILING_KM ? `; ${km} km is self-reported and unverifiable)` : ')');
        rank = 1_000_000;
      } else if (isTarget) {
        cls = 'target';
        reason = `your target — ${Math.round(step)} km past the nearest node we have reached`
          + (km > CEILING_KM ? `; ${km} km is self-reported and unverifiable` : '');
        rank = 500_000 + stepScore;
      } else if (NEW_WINDOW > 0 && r.first_heard
                 && (now - Number(r.first_heard)) < NEW_WINDOW && attempts < MAX_TRIES) {
        // PROBATION, NOT A PRIORITY SPIKE. A new node deserves one aimed run
        // rather than the single passive trace it gets today — 6.9 are
        // discovered a day and only 1 of 11 shortlist entries had been found in
        // the past week. But it does NOT deserve the top of the queue: measured,
        // a first traceroute within an hour of discovery answers 5.9%, against
        // 40.9% for nodes traced days later. Ranking them first would move the
        // budget out of a 16-26% pool and into a 5.9% one.
        cls = 'new';
        reason = `discovered ${fmtSilence(now - Number(r.first_heard))} — never had a proper look`;
        rank = 600 + liveScore;
      } else if (attempts === 0 && km > bar) {
        cls = 'unknown-record';
        reason = `never attempted — ${Math.round(step)} km past the nearest node we have reached, heard ${fmtSilence(silentFor)}, and would beat the ${Math.round(bar)} km best for this period`;
        rank = 1000 + pastScore + contactScore + liveScore + stepScore * 0.2;
      } else if (attempts === 0) {
        cls = 'unknown';
        reason = 'never attempted — one try tells us more than a repeat anywhere';
        rank = 700 + stepScore + liveScore;
      } else if (hits === 0 && km > bar) {
        cls = 'record';
        reason = `${attempts} attempt${attempts === 1 ? '' : 's'}, no reply yet — ${Math.round(step)} km past the nearest node we have reached, heard ${fmtSilence(silentFor)}, would beat the ${Math.round(bar)} km best for this period`;
        // Diminishing: the twentieth silent attempt is worth less than the
        // second. §4 says silence proves nothing, not that it is free.
        rank = 1000 + pastScore + contactScore + liveScore + stepScore * 0.2
             - Math.min(120, attempts * 6);
      } else if (hits > 0 && km > 100 && ageDays != null && ageDays >= 7) {
        cls = 'reconfirm';
        reason = `verified ${hits}/${attempts}, untried for ${ageDays} days — is the corridor still open?`;
        rank = 300 + km + liveScore;
      } else if (hits === 0 && attempts >= MAX_TRIES) {
        // THE ATTEMPT BUDGET. At the frontier's own ~4% base rate one attempt
        // settles nothing, so a target gets MAX_TRIES shots spaced by the
        // cooldown and then retires. Six at thirty minutes is six shots over
        // three hours — against one per day before, which is what made the
        // whole exercise a survey of breadth rather than a search.
        skipped.exhausted++;
        continue;
      } else if (hits === 0 && attempts < MAX_TRIES) {
        // STILL WORTH ASKING. Peter, 2026-08-03: "the ratchet keeps starving the
        // queue - you have glossed over that." He was right, and I had flagged
        // it three times without fixing it.
        //
        // An attempted, unanswered, still-alive node nearer than the bar matched
        // NO class, so it was dropped entirely — the bar was deciding whether we
        // try at all, when ranking and the per-class quotas already decide what
        // goes FIRST. Two different jobs.
        //
        // Measured when this was written: 138 such nodes, 93 heard within 24 h,
        // 82 with fewer than 6 attempts — and the furthest sat at 176.4 km,
        // heard 4 hours earlier, tried EXACTLY ONCE. A node at the frontier,
        // alive, and invisible, purely because it was not PAST the bar.
        //
        // Ranked deliberately BELOW every record class (300 vs 1000) so it can
        // never displace a record attempt — it fills the queue only when nothing
        // better is available, which is precisely when the queue used to empty.
        cls = 'retry';
        reason = `${attempts} attempt${attempts === 1 ? '' : 's'}, no reply yet — `
          + `${Math.round(km)} km is inside the ${Math.round(bar)} km bar, so it cannot move the`
          + ` frontier, but it is alive (heard ${fmtSilence(silentFor)}) and barely asked`;
        rank = 300 + liveScore - Math.min(150, attempts * 25);
      } else {
        // NO CLASS CLAIMS IT — and that is an exclusion like any other.
        //
        // A node that has been attempted, has not answered, and sits NEARER
        // than the period bar matches none of the branches above. It used to
        // leave through a bare `continue`, uncounted, while the comment below
        // promised every exclusion was published.
        //
        // It is not a rounding error. Reconciled 2026-08-03: 607 rows in, 532
        // skipped with a counter, 0 scored — 75 nodes left through here in
        // silence. With `bar` at 176.4 km that is nearly everything still
        // alive, which is why the shortlist was empty and the runner idle with
        // no explanation anywhere on the page.
        skipped.unclassified++;
        continue;
      }

      scored.push({
        entity: String(r.target),
        value: {
          km, cls, reason, attempts, hits,
          // How far past proven ground. The panel shows it because it is the
          // number that says whether an attempt is a step or a leap.
          step_km: step,
          // THE BEARING TRAVELS WITH THE MISSION. Without it the runner cannot
          // aim, and an unaimed YAGI is a worse antenna than an omni — the
          // first discovery run fired a 234 km attempt at whatever azimuth the
          // garage alarm had left the beam on.
          bearing: bearingDeg(HOME.lat, HOME.lon, r.lat, r.lon) == null ? null
                   : Math.round(bearingDeg(HOME.lat, HOME.lon, r.lat, r.lon)),
          last_attempt: lastAtt,
          last_ok: r.last_ok ? Number(r.last_ok) : null,
          age_days: ageDays,
          rank: Math.round(rank),
        },
        confidence: null,
        evidence_count: attempts,
      });
    }

    scored.sort((a, b) => b.value.rank - a.value.rank);

    // A PORTFOLIO, NOT A SORT. Ranked purely by score the shortlist came back as
    // twenty rows of "never attempted, and would beat the 189 km record" —
    // technically the highest information gain, and useless as a mission list.
    // One class swamping the panel hides the record attempts already in flight
    // and the frontier corridors going stale, and those are different kinds of
    // work that want doing in parallel.
    //
    // So each class gets a quota and keeps its own internal ranking. The quotas
    // are a judgement about balance, stated here rather than buried in a score:
    // most effort on ground never covered, real effort on beating the record,
    // and a standing tax on re-confirming what we already hold.
    // REBALANCED once the step metric existed. The old split gave eight slots
    // to `unknown-record` — targets never attempted and beyond the record —
    // and every one of them went to a 100 km leap, crowding out the handful of
    // candidates that sit a short hop past a working corridor. `record` and
    // `unknown-record` now share the same rank scale, so the split is about
    // breadth of evidence rather than about which class wins.
    // QUOTAS BY MODE. `mode` decides whether auto picks at all; `strategy`
    // decides how. In `manual` every automatic class is zero, so a shortlist
    // with nothing pinned or starred comes back EMPTY — and the panel says
    // "MANUAL · nothing pinned" rather than idling with no explanation, which
    // is the failure this whole afternoon was spent chasing.
    const QUOTA = MODE === 'manual'
      ? { pinned: 1, target: 20, new: 0, 'unknown-record': 0, record: 0, reconfirm: 0, unknown: 0, retry: 0 }
      : MODE === 'targets'
        ? { pinned: 1, target: 12, new: 2, 'unknown-record': 3, record: 3, reconfirm: 2, unknown: 1, retry: 2 }
        // `retry` last and generous: it is the class that stops the queue
        // emptying, and it can only ever fill slots the record classes did not.
        // The record classes carry the app's whole purpose, so they get the
        // slots. Previously 6 each, and the six nearest always took them.
        : { pinned: 1, target: 4,  new: 2, 'unknown-record': 12, record: 12, reconfirm: 2, unknown: 3, retry: 3 };
    const used = {};
    const top = [];
    for (const m of scored) {
      const c = m.value.cls;
      if ((used[c] = (used[c] || 0)) >= (QUOTA[c] ?? 0)) continue;
      used[c]++;
      top.push(m);
    }

    // THE EXCLUSIONS ARE PUBLISHED, not silent. A shortlist that quietly drops
    // most of the pool reads as "these are the only options", and §4's whole
    // point is that what we chose not to look at matters as much as what we did.
    top.push({
      entity: 'global',
      value: {
        cls: 'summary',
        // The panel states the rule it is running under, not just its results.
        strategy: STRATEGY,
        mode: MODE,
        pinned: PINNED,
        window_km: STRATEGY === 'ladder' ? WINDOW_KM : null,
        attempts_per_target: MAX_TRIES,
        cooldown_min: Math.round(COOLDOWN / 60),
        record_km: Math.round(record * 10) / 10,
        candidates: scored.length,
        shown: top.length,
        skipped_cooling: skipped.cooling,
        skipped_suspect: skipped.suspect,
        // What `skipped_suspect` actually means, published so the browser
        // states the rule instead of inventing one. It was rendered as "no
        // position" for nodes that every one of them HAS a position for.
        ceiling_km: CEILING_KM,
        // Attempted, unanswered, nearer than the bar — no class claims it.
        skipped_unclassified: skipped.unclassified,
        // NEVER REACHED THE LOOP AT ALL. The evidence query filters these out
        // before any counter exists, so they can only be counted separately.
        // This is the LARGEST exclusion and it was entirely absent from the
        // funnel — the one failure the funnel was built to prevent.
        unpositioned: Number(rows[0]?.unpositioned ?? 0),
        // Every node entering the loop, so the arithmetic can be checked:
        //   rows_in === candidates + every skipped_* counter
        rows_in: rows.length,
        skipped_exhausted: skipped.exhausted,
        skipped_beyond_window: skipped.beyond_window,
        skipped_silent: skipped.silent,
        max_silence_days: Math.round(MAX_SILENT / 86_400),
        proven_min_hits: PROVEN_HITS,
        proven_min_rate: Math.round(PROVEN_RATE * 100),
        new_node_hours: Math.round(NEW_WINDOW / 3600),
        // The window's real anchor, published so the panel can say what the
        // search is measuring from rather than implying it is the record.
        reliable_km: Math.round(reliableKm * 10) / 10,
        // TWO BARS, both stated. record_km is the ultimate goal and stays
        // all-time; `bar_km` is what the ranker actually aims past this period.
        // Publishing only the first is how the search came to chase a month-old
        // number set with antennas that have since moved.
        window_best_km: Math.round(windowBest * 10) / 10,
        bar_km:         Math.round(bar * 10) / 10,
        window_days:    WINDOW_DAYS,
      },
      confidence: null,
      evidence_count: rows.length,
    });
    return top;
  },
});
